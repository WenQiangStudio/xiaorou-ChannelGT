#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 LoRA adapter 合并回底座，导出成可独立部署的完整模型。

用法：
    python scripts/merge_lora.py
    python scripts/merge_lora.py --adapter outputs/xiaorou-lora --out outputs/xiaorou-merged

合并后可以：
    - 直接当普通模型加载（不再需要 peft）
    - 用 llama.cpp / Ollama 转成 GGUF，在没显卡的机器上跑
"""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def choose_base(cfg, model, model_path=None):
    """把 --model 选项映射成实际底座。coder 系列专门加强代码能力。"""
    if model == "custom":
        if not model_path:
            raise SystemExit("[错误] --model custom 需要同时给 --model-path")
        return model_path
    if model == "7b":
        return cfg["base_model_7b"]
    if model == "coder":
        return cfg.get("base_model_coder", "Qwen/Qwen2.5-Coder-1.5B-Instruct")
    if model == "coder7b":
        return cfg.get("base_model_coder_7b", "Qwen/Qwen2.5-Coder-7B-Instruct")
    return cfg["base_model"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["1.5b", "7b", "custom", "coder", "coder7b"],
                    default="1.5b", help="coder / coder7b 用代码专精底座")
    ap.add_argument("--model-path", default=None)
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from peft import PeftModel
    except ImportError as e:
        raise SystemExit(f"[错误] 缺少依赖：{e}\n先执行：pip install -r requirements.txt")

    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    base = choose_base(cfg, args.model, args.model_path)
    adapter = Path(args.adapter or ROOT / cfg["train"]["output_dir"])
    out = Path(args.out or ROOT / "outputs" / "xiaorou-merged")
    if not adapter.exists():
        raise SystemExit(f"[错误] 找不到 adapter：{adapter}")

    print(f"[1/3] 加载底座 {base}（bf16，不量化）")
    model = AutoModelForCausalLM.from_pretrained(
        base, torch_dtype=torch.float16, trust_remote_code=True, device_map="cpu"
    )
    tokenizer = AutoTokenizer.from_pretrained(base, trust_remote_code=True)

    print(f"[2/3] 合并 adapter {adapter.name}")
    model = PeftModel.from_pretrained(model, str(adapter))
    model = model.merge_and_unload()

    print(f"[3/3] 保存到 {out}")
    out.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(str(out), safe_serialization=True)
    tokenizer.save_pretrained(str(out))
    print("[完成] 之后可用 --model custom --model-path " + str(out.relative_to(ROOT)) + " 加载")


if __name__ == "__main__":
    main()
