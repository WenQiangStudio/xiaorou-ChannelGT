#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 knowledge/ 里的资料建成可直接检索的索引（纯标准库，零依赖）。

用法：
    python scripts/build_kb.py
    python scripts/build_kb.py --dir knowledge --out data/kb_index.json

支持 .md / .txt。放进什么资料，小柔就能引用什么资料。
"""
import argparse
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

HAN = re.compile(r"[\u4e00-\u9fff]")

STOP_CHARS = set("的了是在有和就不也都很我你他她它这那什么吗呢吧啊呀为以及与或而但个上下中要会能可说对把被让从到给着过得地还又再只更最太等")
STOP_WORDS = {
    "什么", "怎么", "为什么", "如何", "哪个", "哪些", "是否", "可以", "这个", "那个",
    "我们", "你们", "他们", "因为", "所以", "但是", "如果", "就是", "这样", "那样",
    "一下", "时候", "问题", "觉得", "应该", "需要", "能够", "没有", "不是", "以及",
    "总是", "老是", "一直", "到底", "具体", "一些", "有点",
}


def keep_uni(ch):
    return ch not in STOP_CHARS


def keep_bi(a, b):
    return not (a + b in STOP_WORDS or (a in STOP_CHARS and b in STOP_CHARS))



def tokenize(text):
    """给 token 打类型前缀：w=英文/数字词，u=单字，b=中文二元组。

    二元组和英文词是强信号，单字在中文里几乎每篇都命中，必须降权，
    否则「串联电路」这种知识库里根本没有的问题也会凑出一堆分数。
    """
    s = text.lower()
    words = ["w:" + w for w in re.findall(r"[a-z0-9_]+", s) if w not in STOP_WORDS]
    han = HAN.findall(s)
    uni = ["u:" + c for c in han if keep_uni(c)]
    bi = ["b:" + han[i] + han[i + 1] for i in range(len(han) - 1) if keep_bi(han[i], han[i + 1])]
    return words + uni + bi


def split_paragraphs(text):
    return [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]


def split_sentences(p):
    return [s for s in re.split(r"(?<=[。！？；])", p) if s.strip()]


def chunk_text(text, target=320, hard_max=600):
    """先把段落当单位，太长的段落按句子重组，避免一个 chunk 混进太多主题。"""
    # 标题必须跟着正文进同一个片段，否则「KeyError」这种关键词只在标题里出现，
    # 单独成块会被长度过滤掉，正文就永远检索不到。
    text = re.sub(r"(?m)^(#{1,6}\s+.*)\n+", r"\1 ", text)
    chunks = []
    for p in split_paragraphs(text):
        if len(p) <= target:
            chunks.append(p)
            continue
        buf = ""
        for sent in split_sentences(p):
            if len(buf) + len(sent) > target and buf:
                chunks.append(buf)
                buf = sent
            else:
                buf += sent
            if len(buf) >= hard_max:
                chunks.append(buf)
                buf = ""
        if buf:
            chunks.append(buf)
    return [c for c in chunks if len(c.strip()) >= 20]


def build(files, target=320):
    docs = []
    for path in files:
        text = path.read_text(encoding="utf-8", errors="ignore")
        for piece in chunk_text(text, target=target):
            tf = {}
            for t in tokenize(piece):
                tf[t] = tf.get(t, 0) + 1
            docs.append({
                "source": str(path.relative_to(ROOT)),
                "text": piece,
                "len": len(tokenize(piece)),
                "tf": tf,
            })

    df = {}
    for d in docs:
        for t in d["tf"]:
            df[t] = df.get(t, 0) + 1
    avgdl = sum(d["len"] for d in docs) / len(docs) if docs else 0
    return {
        "version": 1,
        "params": {"k1": 1.5, "b": 0.75},
        "N": len(docs),
        "avgdl": round(avgdl, 3),
        "df": df,
        "docs": docs,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", default="knowledge")
    ap.add_argument("--out", default="data/kb_index.json")
    ap.add_argument("--target", type=int, default=320, help="每个片段的目标字数")
    args = ap.parse_args()

    kb_dir = ROOT / args.dir
    if not kb_dir.exists():
        raise SystemExit(f"[错误] 找不到资料目录 {kb_dir}")
    files = sorted(list(kb_dir.glob("**/*.md")) + list(kb_dir.glob("**/*.txt")))
    if not files:
        raise SystemExit(f"[错误] {kb_dir} 里没有 .md 或 .txt 文件")

    index = build(files, target=args.target)
    out = ROOT / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(index, ensure_ascii=False), encoding="utf-8")

    chars = sum(len(d["text"]) for d in index["docs"])
    print(f"[完成] 资料 {len(files)} 个文件 → {index['N']} 个片段，共 {chars} 字")
    print(f"       词表 {len(index['df'])} 项，平均片段长度 {index['avgdl']} 词")
    print(f"       索引已写入 {out.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
