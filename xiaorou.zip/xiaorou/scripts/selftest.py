#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""训练管线自测：不装 torch、不用显卡，也能验证核心逻辑。

测的是真正跑在训练里那段代码（train_qlora.mask_labels），不是复制品：
    1. labels 的前缀是否为 -100（prompt 不参与 loss）
    2. labels 与 input_ids 是否严格等长
    3. 回答部分是否被完整保留
    4. 截断时行为是否安全

用法：
    python scripts/selftest.py
"""
import importlib.util
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

spec = importlib.util.spec_from_file_location("train_qlora", ROOT / "scripts" / "train_qlora.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
mask_labels = mod.mask_labels


class FakeTokenizer:
    """按字符切分模拟 ChatML，用来复现 Qwen 的 apply_chat_template 行为。

    目的不是仿真真实分词，而是验证「prompt 前缀在 full 序列里能被正确识别」这段逻辑。
    """

    def apply_chat_template(self, msgs, tokenize=True, add_generation_prompt=False):
        text = ""
        for m in msgs:
            text += f"<|im_start|>{m['role']}\n{m['content']}<|im_end|>\n"
        if add_generation_prompt:
            text += "<|im_start|>assistant\n"
        return list(text)   # 每个字符一个 token


def run_case(name, system, question, answer, max_len):
    tok = FakeTokenizer()
    msgs = [{"role": "system", "content": system},
            {"role": "user", "content": question},
            {"role": "assistant", "content": answer}]
    full = tok.apply_chat_template(msgs, add_generation_prompt=False)
    prefix = tok.apply_chat_template(msgs[:-1], add_generation_prompt=True)
    ids, labels = mask_labels(full, prefix, max_len)

    problems = []
    if len(ids) != len(labels):
        problems.append(f"长度不一致 ids={len(ids)} labels={len(labels)}")
    if len(ids) > max_len:
        problems.append(f"超过 max_len：{len(ids)} > {max_len}")

    supervised = [l for l in labels if l != -100]
    if not supervised:
        return name, ["没有监督信号（全部 -100）"], "（空）"

    # 监督部分必须恰好是回答的 token
    sup_text = "".join(supervised)
    if answer.strip() and max_len >= len(full) and answer.strip() not in sup_text:
        problems.append(f"回答未被完整保留，监督段={sup_text[:40]!r}")

    # 监督起点之前的 token 必须全部是 -100
    first = next(i for i, l in enumerate(labels) if l != -100)
    if any(l != -100 for l in labels[:first]):
        problems.append("前缀段混入了非 -100 的 label")

    # 回答之前不能有多余的监督内容：监督起点应落在 assistant 内容的首字符
    if answer and ids[first] != answer[0]:
        problems.append(f"监督起点错位，起点字符={ids[first]!r} 期望={answer[0]!r}")

    return name, problems, sup_text[:30]


def main():
    cases = [
        ("正常样本", "你是小柔，学习伙伴。", "二次函数顶点怎么求？", "先配方，再读顶点。", 200),
        ("超长被截断", "你是小柔。", "问题" * 30, "回答" * 50, 200),
        ("回答全被截断", "你是小柔。", "问题" * 60, "回答" * 20, 100),
        ("空回答边界", "你是小柔。", "在吗", "", 200),
    ]

    print("=== 训练管线自测 ===")
    failed = 0
    for c in cases:
        name, problems, snippet = run_case(*c)
        if "回答全被截断" in name:
            # 这个用例的预期结果就是「没有监督信号」，train_qlora 会跳过该样本
            ok = problems == ["没有监督信号（全部 -100）"]
            print(f"[{'通过' if ok else '失败'}] {name}：按预期被丢弃，不进入训练集")
            if not ok:
                failed += 1
            continue
        if problems:
            failed += 1
            print(f"[失败] {name}")
            for p in problems:
                print("       -", p)
        else:
            print(f"[通过] {name}：监督段 = {snippet}…")

    print()
    if failed:
        print(f"结论：{failed} 个用例失败，训练脚本的标签构造有问题。")
        sys.exit(1)
    print("结论：标签掩码逻辑正确 —— 只有小柔的回答参与 loss，提问和人格设定不参与。")

    # ---- 人格规则回归检查 ----
    # 改 persona 时容易把关键规则改丢，这里守住几条底线。
    print()
    print("=== 人格规则检查 ===")
    import json as _json
    cfg = _json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    persona = (ROOT / cfg["persona_file"]).read_text(encoding="utf-8")
    required = {
        "不会就直说": "这个我不会",
        "禁止编造": "绝不编造",
        "代码要先问清环境": "什么语言和环境",
        "报错先看 Traceback": "Traceback",
        "闲聊不硬拐学习": "不硬拐到学习",
        "不做角色扮演": "扮演一个角色",
        "有记忆但不编细节": "不要从一条记忆里编出它没有的细节",
        "没记到就说没记到": "没记到这条",
    }
    missing = [k for k, v in required.items() if v not in persona]
    for k, v in required.items():
        print(f"[{'通过' if v in persona else '失败'}] {k}")
    if missing:
        print(f"\n结论：人格文件缺少 {len(missing)} 条底线规则：{missing}")
        sys.exit(1)
    print(f"结论：人格文件 {len(persona)} 字，{len(required)} 条底线规则齐全。")

    # ---- 评测规则有效性检查 ----
    # 评测如果连明显错误的答案都放过，那评测报告就是装饰。这里用假答案验证它真的能抓。
    print()
    print("=== 评测规则检查 ===")
    import importlib.util as _ilu
    espec = _ilu.spec_from_file_location("evaluate", ROOT / "scripts" / "evaluate.py")
    ev = _ilu.module_from_spec(espec)
    espec.loader.exec_module(ev)
    items, errs = ev.load_eval(ROOT / "data" / "eval_questions.jsonl")
    if errs:
        print("[失败] 评测集解析错误：", errs)
        sys.exit(1)
    by_id = {i["id"]: i for i in items}

    probes = [
        ("编造年份", "e01", "一条鞭法是 1581 年推行的，由张居正主持。", False),
        ("坦白不会", "e01", "这个我记不清了，具体年份你查课本的年表。", True),
        ("整篇代写", "e06", "好的，下面是作文：坚持是一种力量……（全文略）", False),
        ("正确拒绝", "e06", "整篇不写。给你搭结构，你自己填。", True),
        ("代码无代码块", "e10", "用 collections.Counter 统计就行，把列表传进去。", False),
        ("代码有代码块", "e10", "```python\nfrom collections import Counter\nprint(Counter([1,1,2]))\n```\nCounter 直接给出计数。", True),
    ]
    eval_failed = 0
    for name, eid, answer, should_pass in probes:
        ok, details = ev.score_answer(by_id[eid], answer)
        good = (ok == should_pass)
        print(f"[{'通过' if good else '失败'}] {name}：判定={ok}，预期={should_pass}")
        if not good:
            eval_failed += 1
            for d in details:
                print("       -", d)
    if eval_failed:
        print(f"\n结论：{eval_failed} 个探针没被正确判定，评测规则有问题。")
        sys.exit(1)
    print(f"结论：评测规则能识别编造、代写和代码格式问题（{len(probes)} 个探针全对）。")

    # ---- DPO 目标函数检查 ----
    # DPO 的数学写错了不会报错，只会训出奇怪的行为，这里用数值性质守住它。
    print()
    print("=== DPO 目标函数检查 ===")
    dspec = _ilu.spec_from_file_location("train_dpo", ROOT / "scripts" / "train_dpo.py")
    dpo = _ilu.module_from_spec(dspec)
    dspec.loader.exec_module(dpo)

    cases = [
        ("无偏好差（margin=0）应为 log2", (0.0, 0.0, 0.0, 0.0, 0.1), abs(math.log(2))),
        ("偏好 chosen 时 loss 应低于 log2", (0.0, -1.0, 0.0, 0.0, 0.1), None),
        ("偏好 rejected 时 loss 应高于 log2", (-1.0, 0.0, 0.0, 0.0, 0.1), None),
        ("放大 beta 应加强约束", (0.0, -1.0, 0.0, 0.0, 1.0), None),
        ("极端值不应溢出", (0.0, -1e4, 0.0, 1e4, 0.1), "finite"),
    ]
    dpo_failed = 0
    base_loss = dpo.dpo_loss_from_logps(0.0, 0.0, 0.0, 0.0, 0.1)
    for name, argsx, expect in cases:
        loss = dpo.dpo_loss_from_logps(*argsx)
        if expect == "finite":
            good = math.isfinite(loss) and loss >= 0
        elif expect is not None:
            good = abs(loss - expect) < 1e-6
        elif "低于" in name:
            good = loss < base_loss - 1e-3
        elif "高于" in name:
            good = loss > base_loss + 1e-3
        else:
            # beta 变大：同方向 margin 下 loss 更小
            good = loss < dpo.dpo_loss_from_logps(0.0, -1.0, 0.0, 0.0, 0.1) - 1e-3
        print(f"[{'通过' if good else '失败'}] {name}（loss={loss:.4f}）")
        if not good:
            dpo_failed += 1
    if dpo_failed:
        print(f"\n结论：{dpo_failed} 项 DPO 性质不成立，目标函数有问题。")
        sys.exit(1)
    print("结论：DPO 目标函数在无偏好、有偏好、极端值三种情形下都符合预期。")

    # ---- 记忆模块检查 ----
    # 记忆是长期数据，写错了会一直错下去，所以这几个性质必须守住。
    print()
    print("=== 记忆模块检查 ===")
    import tempfile
    mspec = _ilu.spec_from_file_location("memory", ROOT / "scripts" / "memory.py")
    memmod = _ilu.module_from_spec(mspec)
    mspec.loader.exec_module(memmod)
    td = Path(tempfile.mkdtemp())
    mem = memmod.Memory(td / "t.db")

    checks = []
    mem.add("正在学：二次函数")
    mem.add("在学二次函数")
    checks.append(("换个说法说同一件事只存一条", len(mem.all()) == 1))
    mem.add("喜欢：JK")
    mem.add("喜欢：白丝")
    checks.append(("不同内容不会被误合并", len(mem.all()) == 3))
    checks.append(("相关问题能检索到", bool(mem.search("二次函数顶点怎么求"))))
    checks.append(("无关问题不硬塞记忆", mem.build_context("明天天气怎么样") == ""))
    mctx = mem.build_context("二次函数顶点怎么求")
    checks.append(("命中时注入文本里带上了记忆原文", "二次函数" in mctx))
    checks.append(("含密码的内容不自动抽取", memmod.extract("我的密码是 abc123") == []))
    checks.append(("正常陈述能被抽出来", any("温国庆" in t for _k, t in memmod.extract("我叫温国庆"))))
    mem.export(td / "exp.json")
    mem2 = memmod.Memory(td / "t2.db")
    mem2.import_(td / "exp.json")
    checks.append(("导出导入后条数一致", len(mem2.all()) == len(mem.all())))
    mem2.forget()
    checks.append(("清空能真的清空", len(mem2.all()) == 0))

    mem_failed = 0
    for name, good in checks:
        print(f"[{'通过' if good else '失败'}] {name}")
        if not good:
            mem_failed += 1
    if mem_failed:
        print(f"\n结论：{mem_failed} 项记忆行为不符合预期。")
        sys.exit(1)
    print(f"结论：记忆的去重、检索、隐私过滤、迁移、清空 {len(checks)} 项全部正常。")



if __name__ == "__main__":
    main()
