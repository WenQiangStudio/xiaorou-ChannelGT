#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把训练、对齐、合并后的 HuggingFace 模型转成 GGUF，并量化成手机/电脑能直接加载的档位。

这是整条链路的最后一步：
    SFT(QLoRA) → DPO 对齐 → merge_lora 合并 → 本脚本导出 GGUF

GGUF 是 llama.cpp / Ollama / LM Studio 等工具的推理格式。训练阶段不用它，
训练和合并都在 HF 格式上做，最后才转。

用法：
    python scripts/export_gguf.py --check                       # 只检查输入目录，不转换
    python scripts/export_gguf.py --model-dir outputs/xiaorou-merged
    python scripts/export_gguf.py --model-dir outputs/xiaorou-merged \\
        --llama-cpp /opt/llama.cpp --quants Q3_K_M Q4_K_M
    LLAMA_CPP_DIR=/opt/llama.cpp python scripts/export_gguf.py --model-dir outputs/xiaorou-merged

默认输出两档：Q3_K_M（低配手机）和 Q4_K_M（电脑/高端手机通用）。
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# 量化档位：(名称, 说明, 7B 体积约, 1.5B 体积约)
QUANT_TABLE = {
    "Q2_K":   ("极限压缩，质量明显下降，应急用", "2.7G", "0.6G"),
    "Q3_K_M": ("低配手机首选，体积小、能跑", "3.5G", "0.8G"),
    "Q4_K_M": ("均衡档，手机电脑通用，个人首选", "4.4G", "1.0G"),
    "Q5_K_M": ("高端设备，质量更好", "5.1G", "1.2G"),
    "Q8_0":   ("几乎无损，电脑用，体积大", "7.7G", "1.7G"),
}

# HF 合并目录里必须有的文件，缺了说明 merge_lora 没做完
HF_REQUIRED = ["config.json", "tokenizer.json"]


def find_llama_cpp(hint=None):
    """按顺序找 llama.cpp 目录：参数 → 环境变量 → 常见位置。"""
    candidates = []
    if hint:
        candidates.append(Path(hint))
    if os.environ.get("LLAMA_CPP_DIR"):
        candidates.append(Path(os.environ["LLAMA_CPP_DIR"]))
    candidates += [
        ROOT / "third_party" / "llama.cpp",
        Path("/opt/llama.cpp"),
        Path.home() / "llama.cpp",
        Path.home() / "code" / "llama.cpp",
    ]
    for c in candidates:
        if c and c.exists() and (c / "convert_hf_to_gguf.py").exists():
            return c
    return None


def check_model_dir(model_dir):
    """检查合并后的 HF 目录是否合法，返回问题列表。"""
    model_dir = Path(model_dir)
    problems = []
    if not model_dir.exists():
        problems.append(f"目录不存在：{model_dir}")
        return problems
    for f in HF_REQUIRED:
        if not (model_dir / f).exists():
            problems.append(f"缺少 {f}，这个目录可能还没跑 merge_lora.py")
    # 权重文件：safetensors 或 pytorch_model.bin，至少有一个
    has_weights = bool(list(model_dir.glob("*.safetensors"))) or \
        (model_dir / "pytorch_model.bin").exists()
    if not has_weights:
        problems.append("找不到权重文件（*.safetensors 或 pytorch_model.bin）")
    return problems


def check_only(model_dir):
    print(f"[校验] 模型目录：{model_dir}")
    problems = check_model_dir(model_dir)
    if problems:
        print("[问题]")
        for p in problems:
            print("  -", p)
        raise SystemExit(1)
    print("[通过] 目录结构完整，可以转 GGUF")
    llama = find_llama_cpp()
    if llama:
        print(f"[环境] 已找到 llama.cpp：{llama}")
    else:
        print("[环境] 还没有 llama.cpp。获取方式：")
        print("  git clone https://github.com/ggml-org/llama.cpp")
        print("  cd llama.cpp && cmake -B build && cmake --build build --config Release -j")
        print("  然后用 --llama-cpp 指向它，或设 LLAMA_CPP_DIR")


def run_cmd(cmd, step):
    print(f"[{step}] {' '.join(str(c) for c in cmd)}")
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        print(proc.stdout[-1500:])
        print(proc.stderr[-2000:])
        raise SystemExit(f"[失败] {step}")
    return proc


def export(model_dir, llama_cpp, quants, out_dir):
    problems = check_model_dir(model_dir)
    if problems:
        raise SystemExit("[错误] 输入目录有问题：\n  - " + "\n  - ".join(problems))
    llama = find_llama_cpp(llama_cpp)
    if not llama:
        raise SystemExit(
            "[错误] 找不到 llama.cpp。先 git clone 并用 --llama-cpp 指定，或设 LLAMA_CPP_DIR。")

    model_dir = Path(model_dir)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = model_dir.name

    # 1) 先转成 f16 中间格式
    f16 = out_dir / f"{stem}-f16.gguf"
    converter = llama / "convert_hf_to_gguf.py"
    run_cmd([sys.executable, str(converter), str(model_dir),
             "--outfile", str(f16), "--outtype", "f16"], "1/2 转换 HF→GGUF(f16)")

    # 2) 逐档量化
    quantizer = llama / "build" / "bin" / "llama-quantize"
    if not quantizer.exists():
        quantizer = llama / "llama-quantize"
    if not quantizer.exists():
        # 新版默认构建路径
        alt = list(llama.glob("build/**/llama-quantize"))
        if alt:
            quantizer = alt[0]
    if not quantizer.exists():
        raise SystemExit("[错误] 找不到 llama-quantize，确认 llama.cpp 已完整编译。")

    products = []
    for q in quants:
        if q not in QUANT_TABLE:
            print(f"[跳过] 未知档位 {q}，可选：{', '.join(QUANT_TABLE)}")
            continue
        target = out_dir / f"{stem}-{q.lower()}.gguf"
        run_cmd([str(quantizer), str(f16), str(target), q], f"2/2 量化 {q}")
        size = target.stat().st_size / 1024 ** 3
        products.append((q, target, size))
        print(f"  → {target.name}  实际 {size:.2f} GB，{QUANT_TABLE[q][0]}")

    # f16 中间文件删掉，留着浪费空间；想保留加 --keep-f16
    if not KEEP_F16:
        f16.unlink()
        print("（已删除 f16 中间文件，--keep-f16 可保留）")

    print("\n[完成] 产物清单：")
    for q, target, size in products:
        print(f"  {target}  {size:.2f} GB")
    print("\n加载方式：")
    print("  电脑：LM Studio / Ollama / llama.cpp 直接打开 .gguf")
    print("  手机：MLC LLM / KoboldCpp 导入，详见 docs/MOBILE.md")


KEEP_F16 = False


def main():
    global KEEP_F16
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="只检查输入目录，不转换")
    ap.add_argument("--model-dir", default="outputs/xiaorou-merged")
    ap.add_argument("--llama-cpp", default=None)
    ap.add_argument("--quants", nargs="+", default=["Q3_K_M", "Q4_K_M"])
    ap.add_argument("--out-dir", default="outputs/gguf")
    ap.add_argument("--keep-f16", action="store_true")
    args = ap.parse_args()

    KEEP_F16 = args.keep_f16
    if args.check:
        check_only(args.model_dir)
        return

    print("=== 量化档位参考（7B / 1.5B 体积约）===")
    for name, (desc, s7, s15) in QUANT_TABLE.items():
        print(f"  {name:<7} {s7:>5} / {s15:>4}   {desc}")
    print()
    export(args.model_dir, args.llama_cpp, args.quants, args.out_dir)


if __name__ == "__main__":
    main()
