#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""受限执行一段 Python 代码，用来验证小柔给的代码到底跑不跑得起来。

这不是安全沙箱，是「防手滑」的执行器：限时、禁网、独立临时目录、输出截断。
真正的隔离请用容器或 nsjail，别把它当成不可信代码的执行环境。

用法：
    python scripts/code_runner.py --code "print(sum(range(10)))"
    python scripts/code_runner.py --file /tmp/a.py
    python scripts/code_runner.py --code "..." --timeout 5
    echo "print(1)" | python scripts/code_runner.py
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

MAX_OUTPUT = 4000
DEFAULT_TIMEOUT = 3

# 在用户代码之前注入：禁网络、限制递归深度、把输入置空
PREAMBLE = r'''
import sys, socket

class _NoNetwork(socket.socket):
    def __init__(self, *a, **k):
        raise OSError("执行环境已禁用网络访问")

socket.socket = _NoNetwork
socket.create_connection = lambda *a, **k: (_ for _ in ()).throw(OSError("执行环境已禁用网络访问"))

sys.setrecursionlimit(3000)
'''


def run(code, timeout=DEFAULT_TIMEOUT):
    """执行代码，返回 dict(status, stdout, stderr, duration_ms)。"""
    with tempfile.TemporaryDirectory(prefix="xiaorou_run_") as td:
        script = Path(td) / "main.py"
        script.write_text(PREAMBLE + "\n" + code, encoding="utf-8")

        env = {
            "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
            "PYTHONIOENCODING": "utf-8",
            "HOME": td,
        }
        try:
            proc = subprocess.run(
                [sys.executable, "-I", "-B", str(script)],
                cwd=td, env=env, stdin=subprocess.DEVNULL,
                capture_output=True, text=True, timeout=timeout,
            )
            status = "ok" if proc.returncode == 0 else "error"
            out, err = proc.stdout, proc.stderr
        except subprocess.TimeoutExpired as e:
            status = "timeout"
            out = (e.stdout or "") if isinstance(e.stdout, str) else ""
            err = f"超过 {timeout} 秒未结束，已终止（多半是死循环）"
        except Exception as e:  # noqa: BLE001
            status = "error"
            out, err = "", f"执行器自身异常：{e}"

    if len(out) > MAX_OUTPUT:
        out = out[:MAX_OUTPUT] + f"\n…（输出超过 {MAX_OUTPUT} 字，已截断）"
    if len(err) > MAX_OUTPUT:
        err = err[:MAX_OUTPUT] + f"\n…（错误输出超过 {MAX_OUTPUT} 字，已截断）"
    return {"status": status, "stdout": out.strip(), "stderr": err.strip()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--code", default=None)
    ap.add_argument("--file", default=None)
    ap.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT)
    ap.add_argument("--json", action="store_true", help="输出 JSON，方便被别的脚本调用")
    args = ap.parse_args()

    if args.code is not None:
        code = args.code
    elif args.file:
        code = Path(args.file).read_text(encoding="utf-8")
    elif not sys.stdin.isatty():
        code = sys.stdin.read()
    else:
        raise SystemExit("没有代码可执行。用 --code、--file 或管道传入。")

    r = run(code, timeout=args.timeout)

    if args.json:
        print(json.dumps(r, ensure_ascii=False))
        return

    print(f"[{r['status']}]")
    if r["stdout"]:
        print("--- stdout ---")
        print(r["stdout"])
    if r["stderr"]:
        print("--- stderr ---")
        print(r["stderr"])
    if r["status"] == "ok" and not r["stdout"]:
        print("（执行成功，没有输出）")
    sys.exit(0 if r["status"] == "ok" else 1)


if __name__ == "__main__":
    main()
