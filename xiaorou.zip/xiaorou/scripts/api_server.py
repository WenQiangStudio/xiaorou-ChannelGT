#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把「小柔」包装成 OpenAI 兼容接口，任何支持自定义 API 的客户端都能接。

启动：
    python scripts/api_server.py
    python scripts/api_server.py --adapter outputs/xiaorou-lora --port 8000

接口：
    GET  /health                      -> 服务与模型状态
    GET  /v1/models                   -> 模型列表
    POST /v1/chat/completions         -> 兼容 OpenAI，支持 stream=true

示例：
    curl http://127.0.0.1:8000/v1/chat/completions \
      -H "Content-Type: application/json" \
      -d '{"model":"xiaorou","messages":[{"role":"user","content":"二次函数顶点怎么求"}]}'
"""
import argparse
import json
import threading
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def choose_base(cfg, model, model_path=None):
    """把 --model 选项映射成实际底座。coder 系列专门加强代码能力。"""
    if model == "custom":
        if not model_path:
            raise SystemExit("[错误] --model custom 需要同时给 --model-path")
        return model_path
    if model == "7b":
        return cfg["base_model_7b"]
    if model == "coder":
        return cfg.get("base_model_coder", "Qwen/Qwen2.5-Coder-1.5B-Instruct")
    if model == "coder7b":
        return cfg.get("base_model_coder_7b", "Qwen/Qwen2.5-Coder-7B-Instruct")
    return cfg["base_model"]


def load_config():
    with open(ROOT / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


def _safe_user(user):
    """把 user 字段变成安全的文件名，防止路径穿越。"""
    if not user:
        return "default"
    keep = "".join(c for c in str(user) if c.isalnum() or c in "-_")[:32]
    if not keep:
        import hashlib
        return "u" + hashlib.md5(str(user).encode()).hexdigest()[:12]
    return keep


class MemoryStore:
    """按用户分配记忆库。多个人接同一个服务时，记忆不能串味。"""

    def __init__(self, base_dir):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "memory", Path(__file__).resolve().parent / "memory.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        self.mod = mod
        self.dir = Path(base_dir) / "users"
        self.dir.mkdir(parents=True, exist_ok=True)
        self.cache = {}
        self.lock = threading.Lock()

    def get(self, user):
        uid = _safe_user(user)
        with self.lock:
            if uid not in self.cache:
                self.cache[uid] = self.mod.Memory(self.dir / f"{uid}.db")
            return self.cache[uid]


class XiaorouEngine:
    """把模型加载和生成逻辑收在一处，HTTP 层只做转发。"""

    def __init__(self, base, adapter, persona, gen_cfg, use_4bit=True, kb_index=None):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from peft import PeftModel

        self.torch = torch
        self.gen_cfg = gen_cfg
        self.persona = persona
        self.lock = threading.Lock()

        use_cuda = torch.cuda.is_available()
        dtype = torch.bfloat16 if use_cuda else torch.float32
        kwargs = {"trust_remote_code": True, "torch_dtype": dtype}
        if use_cuda and use_4bit:
            from transformers import BitsAndBytesConfig
            kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True, bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True,
            )
            kwargs["device_map"] = {"": 0}

        self.tokenizer = AutoTokenizer.from_pretrained(base, trust_remote_code=True)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.model = AutoModelForCausalLM.from_pretrained(base, **kwargs)
        if adapter:
            self.model = PeftModel.from_pretrained(self.model, str(adapter))
        if use_cuda and not (use_cuda and use_4bit):
            self.model = self.model.cuda()
        self.model.eval()
        self.base = base
        self.adapter = str(adapter) if adapter else None
        self.kb_index = kb_index
        self._rag = None
        if kb_index:
            try:
                import importlib.util
                from pathlib import Path as _P
                spec = importlib.util.spec_from_file_location(
                    "rag", _P(__file__).resolve().parent / "rag.py")
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                if mod.load(kb_index):
                    self._rag = mod
            except Exception as e:  # noqa: BLE001
                print(f"[提示] 资料库加载失败，按无资料模式提供服务：{e}")
        try:
            self.memory = MemoryStore(ROOT / "memory")
            print(f"[记忆] 已启用，按用户隔离存放在 {self.memory.dir}")
        except Exception as e:  # noqa: BLE001
            self.memory = None
            print(f"[提示] 记忆不可用，按无记忆运行：{e}")

    def _prepare(self, messages, user=None):
        msgs = [m for m in messages if m.get("role") in ("system", "user", "assistant")]
        if msgs and msgs[0]["role"] == "system":
            msgs = msgs[1:]   # 客户端自带的 system 一律让位给小柔人格
        system = self.persona
        if self._rag:
            last_user = next((m["content"] for m in reversed(msgs) if m["role"] == "user"), "")
            try:
                ctx, _hits = self._rag.build_context(last_user, index_path=self.kb_index, topk=3)
            except Exception:  # noqa: BLE001
                ctx = ""
            if ctx:
                system = (self.persona +
                          "\n\n## 本次检索到的资料\n能回答就按资料答；资料里没有的，明说不是资料里的。\n\n"
                          + ctx)
        if self.memory and user is not None:
            last_user = next((m["content"] for m in reversed(msgs) if m["role"] == "user"), "")
            try:
                mctx = self.memory.get(user).build_context(last_user, topk=3)
            except Exception:  # noqa: BLE001
                mctx = ""
            if mctx:
                system = system + "\n\n" + mctx
        msgs = [{"role": "system", "content": system}] + msgs
        text = self.tokenizer.apply_chat_template(
            msgs, tokenize=False, add_generation_prompt=True
        )
        return self.tokenizer(text, return_tensors="pt").to(self.model.device)

    def remember_from(self, messages, user):
        """把用户这句话里明确的事实记下来。抽不到就不写。"""
        if not (self.memory and user):
            return
        last_user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
        try:
            mem = self.memory.get(user)
            for kind, text in mem.extract(last_user):
                mem.add(text, kind)
        except Exception:  # noqa: BLE001
            pass

    def generate(self, messages, temperature=None, top_p=None, max_tokens=None,
                 return_ids=False, user=None):
        torch = self.torch
        inputs = self._prepare(messages, user=user)
        with self.lock, torch.no_grad():
            out = self.model.generate(
                **inputs,
                max_new_tokens=max_tokens or self.gen_cfg["max_new_tokens"],
                temperature=self.gen_cfg["temperature"] if temperature is None else temperature,
                top_p=self.gen_cfg["top_p"] if top_p is None else top_p,
                repetition_penalty=self.gen_cfg["repetition_penalty"],
                do_sample=True,
                pad_token_id=self.tokenizer.pad_token_id,
                eos_token_id=self.tokenizer.eos_token_id,
            )
        new_ids = out[0][inputs["input_ids"].shape[1]:]
        text = self.tokenizer.decode(new_ids, skip_special_tokens=True).strip()
        self.remember_from(messages, user)
        if return_ids:
            return text, new_ids, inputs["input_ids"].shape[1]
        return text

    def stream(self, messages, temperature=None, top_p=None, max_tokens=None, user=None):
        from transformers import TextIteratorStreamer
        torch = self.torch
        inputs = self._prepare(messages, user=user)
        streamer = TextIteratorStreamer(
            self.tokenizer, skip_prompt=True, skip_special_tokens=True
        )
        kw = dict(
            **inputs,
            max_new_tokens=max_tokens or self.gen_cfg["max_new_tokens"],
            temperature=self.gen_cfg["temperature"] if temperature is None else temperature,
            top_p=self.gen_cfg["top_p"] if top_p is None else top_p,
            repetition_penalty=self.gen_cfg["repetition_penalty"],
            do_sample=True,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
            streamer=streamer,
        )

        def run():
            with torch.no_grad():
                self.model.generate(**kw)

        with self.lock:
            t = threading.Thread(target=run, daemon=True)
            t.start()
            for chunk in streamer:
                yield chunk
            t.join(timeout=5)
        self.remember_from(messages, user)


def build_app(engine, cfg):
    from fastapi import FastAPI
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import StreamingResponse
    from pydantic import BaseModel

    app = FastAPI(title="小柔 API", version="1.0")
    app.add_middleware(
        CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
    )

    class Message(BaseModel):
        role: str
        content: str

    class ChatRequest(BaseModel):
        model: str | None = None
        messages: list[Message]
        temperature: float | None = None
        top_p: float | None = None
        max_tokens: int | None = None
        stream: bool = False
        user: str | None = None

    name = cfg["server"]["model_name"]

    @app.get("/health")
    def health():
        return {"status": "ok", "model": name, "base": engine.base, "adapter": engine.adapter}

    @app.get("/v1/models")
    def models():
        return {"object": "list", "data": [{"id": name, "object": "model", "owned_by": "xiaorou"}]}

    @app.get("/v1/memory")
    def memory_list(user: str = "default"):
        if not engine.memory:
            return {"enabled": False, "items": []}
        rows = engine.memory.get(user).all()
        return {"enabled": True, "user": _safe_user(user), "count": len(rows),
                "items": [{"id": r[0], "kind": r[1], "text": r[2]} for r in rows]}

    @app.delete("/v1/memory")
    def memory_clear(user: str = "default"):
        if not engine.memory:
            return {"enabled": False}
        engine.memory.get(user).forget()
        return {"enabled": True, "cleared": True}

    @app.post("/v1/chat/completions")
    def chat(req: ChatRequest):
        msgs = [m.model_dump() for m in req.messages]
        if req.stream:
            def sse():
                for piece in engine.stream(msgs, req.temperature, req.top_p,
                                           req.max_tokens, user=req.user):
                    chunk = {
                        "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                        "object": "chat.completion.chunk",
                        "created": int(time.time()),
                        "model": name,
                        "choices": [{"index": 0, "delta": {"content": piece}, "finish_reason": None}],
                    }
                    yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"
                done = {
                    "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
                    "object": "chat.completion.chunk",
                    "created": int(time.time()),
                    "model": name,
                    "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                }
                yield f"data: {json.dumps(done, ensure_ascii=False)}\n\n"
                yield "data: [DONE]\n\n"
            return StreamingResponse(sse(), media_type="text/event-stream")

        text = engine.generate(msgs, req.temperature, req.top_p, req.max_tokens, user=req.user)
        return {
            "id": f"chatcmpl-{uuid.uuid4().hex[:8]}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": name,
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": text},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
        }

    return app


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["1.5b", "7b", "custom", "coder", "coder7b"],
                    default="1.5b", help="coder / coder7b 用代码专精底座")
    ap.add_argument("--model-path", default=None)
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--no-adapter", action="store_true")
    ap.add_argument("--no-4bit", action="store_true")
    ap.add_argument("--kb", default=None, help="资料索引路径，默认 data/kb_index.json")
    ap.add_argument("--no-kb", action="store_true", help="关闭资料检索")
    ap.add_argument("--host", default=None)
    ap.add_argument("--port", type=int, default=None)
    args = ap.parse_args()

    try:
        import uvicorn
        import torch  # noqa: F401
    except ImportError as e:
        raise SystemExit(f"[错误] 缺少依赖：{e}\n先执行：pip install -r requirements.txt")

    cfg = load_config()
    base = choose_base(cfg, args.model, args.model_path)
    adapter = None if args.no_adapter else Path(args.adapter or ROOT / cfg["train"]["output_dir"])
    if adapter is not None and not adapter.exists():
        print(f"[提示] adapter 目录不存在（{adapter}），以底座 + 人格提示词提供服务。")
        adapter = None

    persona = (ROOT / cfg["persona_file"]).read_text(encoding="utf-8").strip()
    print("[加载] 模型载入中，首次启动需要一点时间…")
    kb_index = None if args.no_kb else (args.kb or str(ROOT / "data" / "kb_index.json"))
    if kb_index and not Path(kb_index).exists():
        kb_index = None
    engine = XiaorouEngine(base, adapter, persona, cfg["infer"],
                           use_4bit=not args.no_4bit, kb_index=kb_index)

    app = build_app(engine, cfg)
    host = args.host or cfg["server"]["host"]
    port = args.port or cfg["server"]["port"]
    print(f"[就绪] http://{host}:{port}  （模型名：{cfg['server']['model_name']}）")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
