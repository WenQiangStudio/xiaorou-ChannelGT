#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""在 Qwen2.5 底座上用 QLoRA 微调「小柔」。

用法：
    python scripts/train_qlora.py                    # 默认 1.5B + 4bit，8G 显存可跑
    python scripts/train_qlora.py --model 7b         # 换 7B 底座（建议 24G 显存）
    python scripts/train_qlora.py --model coder      # 换代码专精底座（写代码更强）
    python scripts/train_qlora.py --no-4bit          # 显存够的话用 bf16 全精度 LoRA
    python scripts/train_qlora.py --epochs 5 --lr 3e-4

前置：先跑 scripts/build_dataset.py 生成 data/train.jsonl。
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


def choose_base(cfg, model, model_path=None):
    """把 --model 选项映射成实际底座。coder 系列专门加强代码能力。"""
    if model == "custom":
        if not model_path:
            raise SystemExit("[错误] --model custom 需要同时给 --model-path")
        return model_path
    if model == "7b":
        return cfg["base_model_7b"]
    if model == "coder":
        return cfg.get("base_model_coder", "Qwen/Qwen2.5-Coder-1.5B-Instruct")
    if model == "coder7b":
        return cfg.get("base_model_coder_7b", "Qwen/Qwen2.5-Coder-7B-Instruct")
    return cfg["base_model"]


def mask_labels(full_ids, prefix_ids, max_len):
    """构造 labels：prompt 部分置 -100，只有 assistant 回答参与 loss。

    返回 (处理后的 input_ids, labels)。纯函数，不依赖 torch，可单独测试。
    """
    # prefix 应当是 full 的真前缀；ChatML 下通常成立，不成立则退化为最长公共前缀
    n = len(prefix_ids)
    if full_ids[:n] != prefix_ids:
        n = 0
        for a, b in zip(full_ids, prefix_ids):
            if a != b:
                break
            n += 1

    if len(full_ids) > max_len:
        full_ids = full_ids[:max_len]
        n = min(n, max_len)

    labels = [-100] * n + full_ids[n:]
    return full_ids, labels


def build_encoded_dataset(path, tokenizer, persona_fallback, max_len):
    """把 {"system","conversations"} 记录编码成 input_ids / labels。"""
    from datasets import Dataset

    rows = []
    truncated = 0
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rec = json.loads(line)
            system = rec.get("system") or persona_fallback
            msgs = [{"role": "system", "content": system}] + rec["conversations"]

            full_ids = tokenizer.apply_chat_template(
                msgs, tokenize=True, add_generation_prompt=False
            )
            prefix_ids = tokenizer.apply_chat_template(
                msgs[:-1], tokenize=True, add_generation_prompt=True
            )

            if len(full_ids) > max_len:
                truncated += 1

            full_ids, labels = mask_labels(full_ids, prefix_ids, max_len)

            if all(l == -100 for l in labels):
                continue  # 答案被截断干净了，这条没有监督信号
            rows.append({"input_ids": full_ids, "labels": labels})

    if truncated:
        print(f"[提示] {truncated} 条超过 max_seq_length={max_len} 被截断，"
              f"如果占比很高，建议把 config.json 里的 max_seq_length 调大")
    if not rows:
        raise SystemExit("[错误] 没有任何可用样本，检查数据格式与 max_seq_length")
    return Dataset.from_list(rows)


def make_collator(tokenizer):
    import torch

    pad_id = tokenizer.pad_token_id

    def collate(features):
        max_len = max(len(f["input_ids"]) for f in features)
        input_ids, labels, attention = [], [], []
        for f in features:
            pad = max_len - len(f["input_ids"])
            input_ids.append(f["input_ids"] + [pad_id] * pad)
            labels.append(f["labels"] + [-100] * pad)
            attention.append([1] * len(f["input_ids"]) + [0] * pad)
        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
            "attention_mask": torch.tensor(attention, dtype=torch.long),
        }

    return collate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["1.5b", "7b", "custom", "coder", "coder7b"],
                    default="1.5b", help="coder / coder7b 用代码专精底座")
    ap.add_argument("--model-path", default=None, help="--model custom 时指定底座路径或 HF 名称")
    ap.add_argument("--data", default=None, help="训练集路径，默认取 config.json")
    ap.add_argument("--epochs", type=float, default=None)
    ap.add_argument("--lr", type=float, default=None)
    ap.add_argument("--no-4bit", action="store_true", help="关闭 4bit 量化（显存需求更高）")
    ap.add_argument("--output", default=None, help="LoRA 输出目录")
    args = ap.parse_args()

    try:
        import torch
        from transformers import (AutoModelForCausalLM, AutoTokenizer, Trainer,
                                  TrainingArguments, set_seed)
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    except ImportError as e:
        raise SystemExit(f"[错误] 缺少依赖：{e}\n先执行：pip install -r requirements.txt")

    if not torch.cuda.is_available():
        raise SystemExit("[错误] 没有检测到 CUDA 显卡。本脚本需要 GPU；"
                         "可以租一台云 GPU（如 AutoDL / RunPod）后再跑。")

    cfg = load_config()
    tcfg = cfg["train"]
    max_len = cfg.get("max_seq_length", 1024)
    data_path = ROOT / (args.data or cfg["data"]["train"])
    if not data_path.exists():
        raise SystemExit(f"[错误] 找不到 {data_path}，先运行 python scripts/build_dataset.py")

    base = choose_base(cfg, args.model, args.model_path)

    out_dir = ROOT / (args.output or tcfg["output_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    use_4bit = not args.no_4bit and tcfg.get("load_in_4bit", True)

    print(f"[1/6] 底座：{base}")
    print(f"      输出：{out_dir}")
    print(f"      4bit：{use_4bit}")

    # ---- tokenizer ----
    tokenizer = AutoTokenizer.from_pretrained(base, trust_remote_code=True, padding_side="right")
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # ---- 数据 ----
    persona = (ROOT / cfg["persona_file"]).read_text(encoding="utf-8").strip()
    print(f"[2/6] 编码数据：{data_path.relative_to(ROOT)}")
    train_ds = build_encoded_dataset(data_path, tokenizer, persona, max_len)

    dev_path = ROOT / cfg["data"]["dev"]
    eval_ds = build_encoded_dataset(dev_path, tokenizer, persona, max_len) if dev_path.exists() else None
    print(f"      训练 {len(train_ds)} 条" + (f"，验证 {len(eval_ds)} 条" if eval_ds else ""))

    # ---- 模型 ----
    print("[3/6] 加载模型…")
    model_kwargs = {"trust_remote_code": True, "torch_dtype": torch.bfloat16}
    if use_4bit:
        from transformers import BitsAndBytesConfig
        model_kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16,
            bnb_4bit_use_double_quant=True,
        )
        model_kwargs["device_map"] = {"": 0}

    model = AutoModelForCausalLM.from_pretrained(base, **model_kwargs)
    model.config.use_cache = False
    if use_4bit:
        model = prepare_model_for_kbit_training(model)

    # ---- LoRA ----
    lora = LoraConfig(
        r=tcfg["lora_r"],
        lora_alpha=tcfg["lora_alpha"],
        lora_dropout=tcfg["lora_dropout"],
        target_modules=tcfg["lora_targets"],
        bias="none",
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()

    # ---- 训练 ----
    epochs = args.epochs or tcfg["epochs"]
    lr = args.lr or tcfg["lr"]
    bf16 = torch.cuda.is_bf16_supported()

    targs = TrainingArguments(
        output_dir=str(out_dir),
        num_train_epochs=epochs,
        per_device_train_batch_size=tcfg["batch_size"],
        per_device_eval_batch_size=tcfg["batch_size"],
        gradient_accumulation_steps=tcfg["grad_accum"],
        learning_rate=lr,
        lr_scheduler_type="cosine",
        warmup_ratio=tcfg["warmup_ratio"],
        weight_decay=tcfg["weight_decay"],
        logging_steps=10,
        save_strategy="epoch",
        save_total_limit=3,
        eval_strategy="epoch" if eval_ds else "no",
        bf16=bf16,
        fp16=not bf16,
        optim="paged_adamw_8bit",
        gradient_checkpointing=tcfg.get("gradient_checkpointing", True),
        gradient_checkpointing_kwargs={"use_reentrant": False},
        report_to="none",
        seed=tcfg["seed"],
        data_seed=tcfg["seed"],
    )
    set_seed(tcfg["seed"])

    trainer = Trainer(
        model=model,
        args=targs,
        train_dataset=train_ds,
        eval_dataset=eval_ds,
        data_collator=make_collator(tokenizer),
    )

    print(f"[4/6] 开始训练：epochs={epochs}，lr={lr}，"
          f"等效 batch={tcfg['batch_size'] * tcfg['grad_accum']}")
    trainer.train()

    # ---- 保存 ----
    print("[5/6] 保存 adapter…")
    trainer.save_model(str(out_dir))
    tokenizer.save_pretrained(str(out_dir))

    metrics = trainer.state.log_history
    final = next((m for m in reversed(metrics) if "loss" in m), {})
    with open(out_dir / "train_summary.json", "w", encoding="utf-8") as f:
        json.dump({
            "base_model": base, "epochs": epochs, "lr": lr,
            "max_seq_length": max_len, "4bit": use_4bit,
            "train_samples": len(train_ds),
            "eval_samples": len(eval_ds) if eval_ds else 0,
            "final_train_loss": final.get("loss"),
            "log": metrics,
        }, f, ensure_ascii=False, indent=2)

    print(f"[6/6] 完成。adapter 在 {out_dir}")
    print("      下一步：python scripts/infer.py --adapter " + str(out_dir.relative_to(ROOT)))


if __name__ == "__main__":
    main()
