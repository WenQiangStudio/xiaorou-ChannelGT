#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""小柔的长期记忆：本地 SQLite，零依赖，不上传任何东西。

记忆分三类，用途不同：
    fact        事实——「我在学二次函数」「我的课本是人教版」
    preference  偏好——「讲题时先给结论」「别用英文术语」
    event       事件——「上次那道题我在配方那步卡住」

检索不是把全部记忆塞进提示词（那会污染上下文），而是按当前问题挑相关的几条。
打分 = 词重合 + 新近度衰减 + 使用次数，三项都有上限，防止某条记忆霸屏。

用法：
    python scripts/memory.py add "我在学二次函数" --kind fact
    python scripts/memory.py search "二次函数"
    python scripts/memory.py list
    python scripts/memory.py forget --id 3
    python scripts/memory.py forget --all
    python scripts/memory.py auto "我叫温国庆，现在在学二次函数"   # 从一句话抽候选
    python scripts/memory.py export memory.json
"""
import argparse
import json
import math
import re
import sqlite3
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "memory" / "memory.db"
MAX_ITEMS = 500

STOP_CHARS = set("的了是在有和就不也都很我你他她它这那什么吗呢吧啊呀为以及与或而但个上下中要会能可说对把被让从到给着过得地还又再只更最太等")
STOP_WORDS = {"什么", "怎么", "为什么", "如何", "哪个", "哪些", "是否", "可以", "这个",
              "那个", "我们", "你们", "他们", "因为", "所以", "但是", "如果", "就是",
              "这样", "那样", "一下", "时候", "问题", "觉得", "应该", "需要", "能够"}

# 这些内容不自动入库。账号、密码、住址一旦写进库，导出去就跟着走了。
SENSITIVE = ("密码", "账号", "身份证", "银行卡", "手机号", "电话号码", "住址",
             "家庭地址", "验证码", "支付")

# 从一句话里抽事实的规则。宁可少抽，不要错抽——错的记忆比没有记忆更糟。
EXTRACT_RULES = [
    (r"我叫([\u4e00-\u9fffA-Za-z]{1,10})", "fact", "名字：{0}"),
    (r"我的名字是([\u4e00-\u9fffA-Za-z]{1,10})", "fact", "名字：{0}"),
    (r"我(?:现在|最近)?在学([\u4e00-\u9fffA-Za-z0-9]{2,12})", "fact", "正在学：{0}"),
    (r"我喜欢([\u4e00-\u9fffA-Za-z0-9]{2,12})", "preference", "喜欢：{0}"),
    (r"我(?:很)?讨厌([\u4e00-\u9fffA-Za-z0-9]{2,12})", "preference", "讨厌：{0}"),
    (r"我的生日是([0-9]{1,2}月[0-9]{1,2}[日号])", "fact", "生日：{0}"),
    (r"我今年([0-9]{1,2})岁", "fact", "年龄：{0} 岁"),
    (r"我们(?:学校)?用的是([\u4e00-\u9fffA-Za-z0-9]{2,15})教材", "fact", "教材：{0}"),
]


def tokenize(text):
    s = text.lower()
    han = re.findall(r"[\u4e00-\u9fff]", s)
    words = ["w:" + w for w in re.findall(r"[a-z0-9_]+", s) if w not in STOP_WORDS]
    uni = ["u:" + c for c in han if c not in STOP_CHARS]
    bi = ["b:" + han[i] + han[i + 1] for i in range(len(han) - 1)
          if not (han[i] + han[i + 1] in STOP_WORDS
                  or (han[i] in STOP_CHARS and han[i + 1] in STOP_CHARS))]
    return words + uni + bi


def term_weight(t):
    return 1.6 if t.startswith(("b:", "w:")) else 0.45


def norm_text(text):
    return re.sub(r"[^\u4e00-\u9fffA-Za-z0-9]", "", text).lower()


class Memory:
    def __init__(self, path=None):
        self.path = Path(path or DB_PATH)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path))
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL DEFAULT 'fact',
                text TEXT NOT NULL,
                norm TEXT NOT NULL UNIQUE,
                created REAL NOT NULL,
                updated REAL NOT NULL,
                hits INTEGER NOT NULL DEFAULT 0,
                last_used REAL NOT NULL DEFAULT 0
            )""")
        self.conn.commit()

    # ---------- 写 ----------
    def add(self, text, kind="fact", tags=None):
        text = text.strip()
        if not text:
            return None
        norm = norm_text(text)
        if not norm:
            return None
        now = time.time()
        cur = self.conn.execute("SELECT id FROM memories WHERE norm = ?", (norm,))
        row = cur.fetchone()
        if row:  # 同一条再说一遍，只刷新时间，不重复存
            self.conn.execute("UPDATE memories SET updated = ? WHERE id = ?", (now, row[0]))
            self.conn.commit()
            return row[0]

        # 换个说法说的同一件事，别存两条。重合 80% 以上视为同一条，用新说法覆盖旧的。
        nt = set(tokenize(text))
        if nt:
            for rid, _k, old, _c, _h in self.conn.execute(
                    "SELECT id, kind, text, created, hits FROM memories").fetchall():
                other = set(tokenize(old))
                if not other:
                    continue
                jaccard = len(nt & other) / len(nt | other)
                if jaccard >= 0.80:
                    self.conn.execute(
                        "UPDATE memories SET text=?, norm=?, updated=? WHERE id=?",
                        (text, norm, now, rid))
                    self.conn.commit()
                    return rid
        cur = self.conn.execute(
            "INSERT INTO memories (kind, text, norm, created, updated) VALUES (?,?,?,?,?)",
            (kind, text, norm, now, now))
        self.conn.commit()
        self._enforce_limit()
        return cur.lastrowid

    def _enforce_limit(self):
        n = self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        if n <= MAX_ITEMS:
            return
        # 先淘汰最久没被用、命中最少的
        self.conn.execute(
            """DELETE FROM memories WHERE id IN (
                   SELECT id FROM memories ORDER BY hits ASC, last_used ASC LIMIT ?)""",
            (n - MAX_ITEMS,))
        self.conn.commit()

    def forget(self, mem_id=None):
        if mem_id is None:
            self.conn.execute("DELETE FROM memories")
        else:
            self.conn.execute("DELETE FROM memories WHERE id = ?", (mem_id,))
        self.conn.commit()

    # ---------- 读 ----------
    def all(self):
        return self.conn.execute(
            "SELECT id, kind, text, created, hits FROM memories ORDER BY id").fetchall()

    def search(self, query, topk=3, min_score=1.2):
        rows = self.conn.execute(
            "SELECT id, kind, text, created, hits FROM memories").fetchall()
        if not rows:
            return []
        q_tokens = set(tokenize(query))
        if not q_tokens:
            return []

        df = {}
        doc_tokens = {}
        for rid, _k, text, _c, _h in rows:
            ts = set(tokenize(text))
            doc_tokens[rid] = ts
            for t in ts:
                df[t] = df.get(t, 0) + 1
        n = len(rows)
        now = time.time()

        scored = []
        for rid, kind, text, created, hits in rows:
            overlap = 0.0
            for t in q_tokens & doc_tokens[rid]:
                idf = math.log(1 + (n - df.get(t, 1) + 0.5) / (df.get(t, 1) + 0.5))
                overlap += term_weight(t) * idf
            if overlap <= 0:
                continue
            age_days = max(0.0, (now - created) / 86400)
            recency = math.exp(-age_days / 45)       # 45 天半衰
            freq = min(1.0, math.log1p(hits) / 3)    # 用过 20 次封顶
            score = overlap + 0.35 * recency + 0.2 * freq
            scored.append((score, rid, kind, text))

        scored.sort(reverse=True, key=lambda x: x[0])
        out = [s for s in scored if s[0] >= min_score][:topk]

        # 用过就记一次，让常用记忆排前面
        for _s, rid, _k, _t in out:
            self.conn.execute(
                "UPDATE memories SET hits = hits + 1, last_used = ? WHERE id = ?",
                (time.time(), rid))
        self.conn.commit()
        return out

    def build_context(self, query, topk=3):
        """把命中的记忆拼成一段可注入 system 的文本；没命中返回空串。"""
        hits = self.search(query, topk=topk)
        if not hits:
            return ""
        lines = ["## 你记得的事（来自过去的对话，用它但别乱编）"]
        for _s, _rid, kind, text in hits:
            lines.append(f"- [{kind}] {text}")
        lines.append("这些是用户以前说过的。和当前问题无关就别硬提；"
                     "用户说记错了，以他这次说的为准。")
        return "\n".join(lines)

    def extract(self, text):
        """规则抽取消记忆候选，供对话时自动写入。"""
        return extract(text)

    # ---------- 迁移 ----------
    def export(self, path):
        data = [{"kind": k, "text": t, "created": c, "hits": h}
                for _i, k, t, c, h in self.all()]
        Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return len(data)

    def import_(self, path):
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        for item in data:
            self.add(item["text"], item.get("kind", "fact"))
        return len(data)


def extract(text):
    """从一句话里抽候选记忆。返回 [(kind, text)]，只抽规则命中的。

    含账号、密码、住址这类内容整句跳过，不抽任何东西。
    """
    if any(w in text for w in SENSITIVE):
        return []
    out = []
    for pat, kind, tpl in EXTRACT_RULES:
        for m in re.finditer(pat, text):
            frag = tpl.format(m.group(1))
            if len(frag) >= 3:
                out.append((kind, frag))
    # 简单去重
    seen, uniq = set(), []
    for k, t in out:
        if t not in seen:
            seen.add(t)
            uniq.append((k, t))
    return uniq


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("add")
    p.add_argument("text")
    p.add_argument("--kind", default="fact", choices=["fact", "preference", "event"])
    p.add_argument("--db", default=None)

    p = sub.add_parser("search")
    p.add_argument("query")
    p.add_argument("--topk", type=int, default=5)
    p.add_argument("--db", default=None)

    p = sub.add_parser("list")
    p.add_argument("--db", default=None)

    p = sub.add_parser("forget")
    p.add_argument("--id", type=int, default=None)
    p.add_argument("--all", action="store_true")
    p.add_argument("--db", default=None)

    p = sub.add_parser("auto")
    p.add_argument("text")
    p.add_argument("--db", default=None)

    p = sub.add_parser("export")
    p.add_argument("path")
    p.add_argument("--db", default=None)

    p = sub.add_parser("import")
    p.add_argument("path")
    p.add_argument("--db", default=None)

    args = ap.parse_args()
    m = Memory(getattr(args, "db", None))

    if args.cmd == "add":
        rid = m.add(args.text, args.kind)
        print(f"已记住（id={rid}）：{args.text}")
    elif args.cmd == "search":
        hits = m.search(args.query, topk=args.topk, min_score=0)
        if not hits:
            print("没有相关记忆。")
        for score, rid, kind, text in hits:
            print(f"  [{score:.2f}] #{rid} ({kind}) {text}")
    elif args.cmd == "list":
        rows = m.all()
        if not rows:
            print("记忆库是空的。")
        for i, k, t, c, h in rows:
            print(f"  #{i} [{k}] {t}（命中 {h} 次）")
    elif args.cmd == "forget":
        if args.all:
            m.forget()
            print("已清空全部记忆。")
        elif args.id:
            m.forget(args.id)
            print(f"已删除 #{args.id}。")
        else:
            raise SystemExit("用 --id N 删一条，或 --all 清空")
    elif args.cmd == "auto":
        cands = extract(args.text)
        if not cands:
            print("没抽出可记的内容。")
        for kind, t in cands:
            rid = m.add(t, kind)
            print(f"  #{rid} [{kind}] {t}")
    elif args.cmd == "export":
        print(f"已导出 {m.export(args.path)} 条到 {args.path}")
    elif args.cmd == "import":
        print(f"已导入 {m.import_(args.path)} 条")


if __name__ == "__main__":
    main()
