#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""校验种子数据集并切分为训练集 / 验证集。

只依赖标准库，任何机器都能跑。用法：
    python scripts/build_dataset.py            # 用 config.json 里的路径
    python scripts/build_dataset.py --strict   # 有错误直接退出（适合接进 CI）
"""
import argparse
import json
import random
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


def load_persona(cfg):
    p = ROOT / cfg["persona_file"]
    if not p.exists():
        raise SystemExit(f"[错误] 找不到人格文件：{p}")
    return p.read_text(encoding="utf-8").strip()


def check_sample(obj, idx):
    """返回 (errors, warnings)。"""
    errors, warnings = [], []
    if not isinstance(obj, dict):
        return [f"第 {idx} 条不是 JSON 对象"], []
    conv = obj.get("conversations")
    if not isinstance(conv, list) or len(conv) < 2:
        return [f"第 {idx} 条 conversations 缺失或不足两轮"], []
    if len(conv) % 2 != 0:
        errors.append(f"第 {idx} 条轮数不是偶数（应以 user 开始、assistant 结尾）")
    for j, turn in enumerate(conv):
        if not isinstance(turn, dict) or "role" not in turn or "content" not in turn:
            errors.append(f"第 {idx} 条第 {j + 1} 轮缺少 role/content")
            continue
        expect = "user" if j % 2 == 0 else "assistant"
        if turn["role"] != expect:
            errors.append(f"第 {idx} 条第 {j + 1} 轮角色应为 {expect}，实际是 {turn['role']}")
        if not str(turn["content"]).strip():
            errors.append(f"第 {idx} 条第 {j + 1} 轮内容为空")
    meta = obj.get("meta")
    if not isinstance(meta, dict):
        warnings.append(f"第 {idx} 条缺少 meta，统计时会归为未分类")
    return errors, warnings


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strict", action="store_true", help="存在错误时以非零状态退出")
    args = ap.parse_args()

    cfg = load_config()
    dcfg = cfg["data"]
    seed_path = ROOT / dcfg["seed"]
    if not seed_path.exists():
        raise SystemExit(f"[错误] 找不到种子数据：{seed_path}")

    persona = load_persona(cfg)

    samples, errors, warnings = [], [], []
    seen, dup = set(), []
    with open(seed_path, "r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                errors.append(f"第 {i} 行 JSON 解析失败：{e}")
                continue
            errs, warns = check_sample(obj, i)
            errors.extend(errs)
            warnings.extend(warns)
            if errs:
                continue
            # 按整段对话指纹去重：同一个问题可以有多种讲法，只有完全一样才算重复
            fingerprint = json.dumps(obj["conversations"], ensure_ascii=False, sort_keys=True)
            if fingerprint in seen:
                dup.append(obj["conversations"][0]["content"][:30])
                continue
            seen.add(fingerprint)
            samples.append(obj)

    if dup:
        warnings.append(f"发现 {len(dup)} 条完全重复的对话，已去重：{dup}")

    # 统计
    total_turns = sum(len(s["conversations"]) // 2 for s in samples)
    chars = sum(len(t["content"]) for s in samples for t in s["conversations"])
    subject = Counter((s.get("meta") or {}).get("subject", "未分类") for s in samples)
    short = [s["conversations"][0]["content"][:20] for s in samples
             if len(s["conversations"][0]["content"]) < dcfg.get("min_chars", 8)
             and (s.get("meta") or {}).get("type") not in ("greeting", "chat")]
    for q in short:
        warnings.append(f"提问过短（低于 {dcfg.get('min_chars', 8)} 字）：{q}")

    # 注入 system，切分
    rng = random.Random(cfg["train"]["seed"])
    rng.shuffle(samples)
    dev_n = max(1, int(len(samples) * dcfg.get("dev_ratio", 0.1))) if len(samples) >= 10 else 0
    dev, train = samples[:dev_n], samples[dev_n:]

    def dump(items, path):
        with open(path, "w", encoding="utf-8") as f:
            for s in items:
                rec = {"system": persona, "conversations": s["conversations"]}
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    train_path, dev_path = ROOT / dcfg["train"], ROOT / dcfg["dev"]
    dump(train, train_path)

    report = [
        "# 小柔数据集报告",
        "",
        f"- 种子文件：`{dcfg['seed']}`",
        f"- 有效样本：**{len(samples)}** 条（{total_turns} 轮问答，共 {chars} 字）",
        f"- 训练集：`{dcfg['train']}`，{len(train)} 条",
        f"- 验证集：`{dcfg['dev']}`，{len(dev)} 条",
        f"- 平均单条长度：{chars // max(1, len(samples))} 字",
        "",
        "## 学科分布",
        "",
        "| 学科 | 条数 |",
        "| --- | --- |",
    ]
    for k, v in subject.most_common():
        report.append(f"| {k} | {v} |")
    report += ["", "## 检查结果", ""]
    report.append(f"- 错误：{len(errors)}")
    for e in errors:
        report.append(f"  - {e}")
    report.append(f"- 警告：{len(warnings)}")
    for w in warnings:
        report.append(f"  - {w}")
    if not errors and not warnings:
        report.append("  - 无")
    report += [
        "",
        "## 下一步",
        "",
        "```bash",
        "python scripts/check_env.py          # 确认显卡和依赖",
        "python scripts/train_qlora.py        # 开始训练 LoRA",
        "python scripts/infer.py              # 训练完跟小柔对话",
        "```",
    ]

    if dev_n == 0:
        print("[提示] 样本少于 10 条，本次不生成验证集。")
    else:
        dump(dev, dev_path)

    rp = ROOT / "data" / "dataset_report.md"
    rp.write_text("\n".join(report) + "\n", encoding="utf-8")

    print(f"[完成] 有效 {len(samples)} 条 → 训练 {len(train)} / 验证 {len(dev)}")
    print(f"[完成] 报告已写入 {rp.relative_to(ROOT)}")
    if errors:
        print(f"[错误] {len(errors)} 条问题：")
        for e in errors:
            print("  -", e)
    if warnings:
        print(f"[警告] {len(warnings)} 条提示（详见报告）")
    if errors and args.strict:
        sys.exit(1)


if __name__ == "__main__":
    main()
