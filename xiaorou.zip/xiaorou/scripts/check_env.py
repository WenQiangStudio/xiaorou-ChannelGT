#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""训练前自检：依赖、显卡、显存、数据是否就绪。

只依赖标准库，任何机器都能跑：
    python scripts/check_env.py
"""
import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PKGS = ["torch", "transformers", "peft", "bitsandbytes", "datasets", "accelerate", "fastapi", "uvicorn"]


def has(mod):
    return importlib.util.find_spec(mod) is not None


def main():
    ok, warn, fail = [], [], []

    # Python
    v = sys.version_info
    if v >= (3, 9):
        ok.append(f"Python {v.major}.{v.minor}.{v.micro}")
    else:
        fail.append(f"Python {v.major}.{v.minor} 过低，需要 3.9 以上")

    # 依赖
    missing = [p for p in PKGS if not has(p)]
    if not missing:
        ok.append("Python 依赖齐全")
    else:
        fail.append("缺少依赖：" + ", ".join(missing) + "（执行 pip install -r requirements.txt）")

    # 显卡
    if shutil.which("nvidia-smi"):
        try:
            out = subprocess.check_output(
                ["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
                 "--format=csv,noheader"], text=True, timeout=20).strip()
            for line in out.splitlines():
                ok.append("GPU：" + line)
        except Exception as e:  # noqa: BLE001
            warn.append(f"nvidia-smi 存在但读取失败：{e}")
        if has("torch"):
            try:
                import torch
                if torch.cuda.is_available():
                    total = torch.cuda.get_device_properties(0).total_memory / 1024 ** 3
                    ok.append(f"CUDA 可用，显存 {total:.1f} GB，bf16 "
                              f"{'支持' if torch.cuda.is_bf16_supported() else '不支持（回退 fp16）'}")
                    if total >= 16:
                        ok.append("显存够跑 7B 4bit（建议 --model 7b）")
                    elif total >= 7:
                        warn.append(f"显存 {total:.1f} GB：建议用 1.5B + 4bit（默认配置），"
                                    f"7B 可能 OOM")
                    else:
                        fail.append(f"显存不足 {total:.1f} GB，训练会 OOM，建议租云 GPU")
                else:
                    fail.append("torch 检测不到 CUDA，训练无法进行")
            except Exception as e:  # noqa: BLE001
                warn.append(f"torch 存在但 CUDA 自检失败：{e}")
    else:
        fail.append("没有检测到 NVIDIA 显卡 / nvidia-smi：本机不能训练，"
                    "请换 GPU 机器或租云 GPU（训练脚本本身无需改动）")

    # 数据
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    train = ROOT / cfg["data"]["train"]
    if train.exists():
        n = sum(1 for line in train.read_text(encoding="utf-8").splitlines() if line.strip())
        if n >= 100:
            ok.append(f"训练数据 {n} 条")
        else:
            warn.append(f"训练数据只有 {n} 条：能跑出效果但很有限，建议扩充到 300 条以上")
    else:
        fail.append("还没有 data/train.jsonl，先执行 python scripts/build_dataset.py")

    if (ROOT / cfg["persona_file"]).exists():
        ok.append("人格文件存在")
    else:
        fail.append(f"缺少人格文件 {cfg['persona_file']}")

    adapter = ROOT / cfg["train"]["output_dir"]
    if adapter.exists():
        ok.append(f"已有 adapter：{adapter.relative_to(ROOT)}（可直接 python scripts/infer.py）")

    # 输出
    print("\n=== 小柔 环境自检 ===")
    for t, items in (("通过", ok), ("注意", warn), ("阻塞", fail)):
        for it in items:
            print(f"[{t}] {it}")
    print()
    if fail:
        print("结论：当前机器还不能训练，先把上面 [阻塞] 的项解决。")
        print("      没有显卡也可以先跑：python scripts/build_dataset.py 和阅读 README 的云 GPU 部分。")
        sys.exit(1)
    if warn:
        print("结论：可以训练，但有上面那些需要注意的点。")
    else:
        print("结论：一切就绪，直接 python scripts/train_qlora.py")


if __name__ == "__main__":
    main()
