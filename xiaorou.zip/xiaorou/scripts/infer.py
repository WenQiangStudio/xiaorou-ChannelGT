#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""命令行里跟「小柔」对话。

两种后端，按机器能力自己选：
    local  本地跑模型，有显卡用 GPU，没显卡自动退到 CPU
    api    本地不加模型，直接调 OpenAI 兼容接口（没有显卡的机器用这个）

用法：
    python scripts/infer.py                              # 自动判断设备
    python scripts/infer.py --adapter outputs/xiaorou-lora
    python scripts/infer.py --no-adapter                 # 底座+人格，做对照
    python scripts/infer.py --model 7b
    python scripts/infer.py --device cpu                 # 强制 CPU
    python scripts/infer.py --backend api                # 走 API
    python scripts/infer.py --once "二次函数顶点怎么求"

对话中可用：
    /reset            清空上下文
    /remember 内容     手动记一条
    /memory           看记住了什么
    /forget           清空记忆（会再确认一次）
    /exit             退出
"""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


def choose_base(cfg, model, model_path=None):
    if model == "custom":
        if not model_path:
            raise SystemExit("[错误] --model custom 需要同时给 --model-path")
        return model_path
    return {
        "7b": cfg["base_model_7b"],
        "coder": cfg.get("base_model_coder", "Qwen/Qwen2.5-Coder-1.5B-Instruct"),
        "coder7b": cfg.get("base_model_coder_7b", "Qwen/Qwen2.5-Coder-7B-Instruct"),
    }.get(model, cfg["base_model"])


def load_memory(path=None):
    """记忆是本地 SQLite，坏了也不该挡住对话，所以失败就降级成没有记忆。"""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "memory", Path(__file__).resolve().parent / "memory.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.Memory(path)
    except Exception as e:  # noqa: BLE001
        print(f"[提示] 记忆功能不可用，按无记忆运行：{e}")
        return None


def load_rag():
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "rag", Path(__file__).resolve().parent / "rag.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception:  # noqa: BLE001
        return None


def build_system(persona, rag, kb_index, mem, query):
    """按当前这句话拼 system：人格 + 检索资料 + 相关记忆。命中才加，不硬塞。"""
    parts = [persona]
    if rag and kb_index:
        try:
            ctx, _hits = rag.build_context(query, index_path=kb_index, topk=3)
        except Exception as e:  # noqa: BLE001
            print(f"[提示] 检索出错，本次不用资料：{e}")
            ctx = ""
        if ctx:
            parts.append("## 本次检索到的资料\n能回答就按资料答；资料里没有的，明说不是资料里的，"
                         "不要拿资料外的内容冒充资料。\n\n" + ctx)
    if mem:
        try:
            mctx = mem.build_context(query, topk=3)
        except Exception:  # noqa: BLE001
            mctx = ""
        if mctx:
            parts.append(mctx)
    return "\n\n".join(parts)


def remember_auto(mem, text):
    """从用户这句话里抽明确的事实，抽到就记，并告诉用户记了什么。"""
    if not mem:
        return
    try:
        cands = mem.extract(text)
    except Exception:  # noqa: BLE001
        return
    for kind, t in cands:
        rid = mem.add(t, kind)
        print(f"  （已记住 #{rid}：{t}，想删输入 /forget）")


def handle_command(user, state, mem):
    """返回 True 表示这条是命令，已处理完，不再送模型。"""
    if user in ("/exit", "exit", "quit"):
        print("再见。")
        raise SystemExit(0)
    if user == "/reset":
        state["history"] = []
        print("（上下文已清空）\n")
        return True
    if user.startswith("/remember"):
        text = user[len("/remember"):].strip()
        if not text:
            print("用法：/remember 我在学二次函数")
        elif mem is None:
            print("记忆功能不可用。")
        else:
            rid = mem.add(text, "fact")
            print(f"（已记住 #{rid}：{text}）\n")
        return True
    if user == "/memory":
        if mem is None:
            print("记忆功能不可用。")
            return True
        rows = mem.all()
        if not rows:
            print("（还没有记忆）\n")
        else:
            print(f"（共 {len(rows)} 条）")
            for i, k, t, _c, h in rows:
                print(f"  #{i} [{k}] {t}")
            print()
        return True
    if user == "/forget":
        if mem is None:
            return True
        ans = input("确认清空全部记忆？输入 y 确认：").strip().lower()
        if ans == "y":
            mem.forget()
            print("（记忆已清空）\n")
        else:
            print("（已取消）\n")
        return True
    return False


# ---------------------------- 本地后端 ----------------------------
def run_local(args, cfg, persona, rag, kb_index, mem, state):
    try:
        import torch
        from transformers import (AutoModelForCausalLM, AutoTokenizer, TextStreamer)
        from peft import PeftModel
    except ImportError as e:
        raise SystemExit(f"[错误] 缺少依赖：{e}\n"
                         "没有显卡的机器建议直接用 --backend api，不必装 torch。")

    icfg = cfg["infer"]
    base = choose_base(cfg, args.model, args.model_path)

    adapter = None if args.no_adapter else Path(args.adapter or ROOT / cfg["train"]["output_dir"])
    if adapter is not None and not adapter.exists():
        print(f"[提示] 没找到 adapter 目录 {adapter}，将以「底座 + 人格」运行。")
        adapter = None

    use_cuda = torch.cuda.is_available() and args.device != "cpu"
    dtype = torch.bfloat16 if use_cuda else torch.float32
    print(f"[加载] 底座 {base}" + (f" + adapter {adapter.name}" if adapter else "（未挂 adapter）"))
    print(f"[设备] {'GPU' if use_cuda else 'CPU（会慢，但能跑）'}")

    model_kwargs = {"trust_remote_code": True, "torch_dtype": dtype}
    if use_cuda and not args.no_4bit:
        from transformers import BitsAndBytesConfig
        model_kwargs["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True)
        model_kwargs["device_map"] = {"": 0}
    model = AutoModelForCausalLM.from_pretrained(base, **model_kwargs)

    tokenizer = AutoTokenizer.from_pretrained(base, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    if adapter:
        model = PeftModel.from_pretrained(model, str(adapter))
    if use_cuda and args.no_4bit:
        model = model.cuda()
    model.eval()

    max_new = args.max_new_tokens or icfg["max_new_tokens"]

    def reply(user_text):
        system = build_system(persona, rag, kb_index, mem, user_text)
        msgs = [{"role": "system", "content": system}] + state["history"] + \
               [{"role": "user", "content": user_text}]
        text = tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        inputs = tokenizer(text, return_tensors="pt").to(model.device)
        streamer = TextStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True) \
            if not args.once else None
        with torch.no_grad():
            out = model.generate(
                **inputs, streamer=streamer,
                max_new_tokens=max_new,
                temperature=icfg["temperature"], top_p=icfg["top_p"],
                repetition_penalty=icfg["repetition_penalty"], do_sample=True,
                pad_token_id=tokenizer.pad_token_id, eos_token_id=tokenizer.eos_token_id)
        answer = tokenizer.decode(out[0][inputs["input_ids"].shape[1]:],
                                  skip_special_tokens=True).strip()
        state["history"] += [{"role": "user", "content": user_text},
                             {"role": "assistant", "content": answer}]
        return answer

    return reply


# ---------------------------- API 后端 ----------------------------
def run_api(args, cfg, persona, rag, kb_index, mem, state):
    """零依赖调用 OpenAI 兼容 /chat/completions。"""

    api_base = (args.api_base or os.environ.get("OPENAI_BASE_URL")
                or "https://api.openai.com/v1").rstrip("/")
    api_key = args.api_key or os.environ.get("OPENAI_API_KEY", "")
    model_name = args.api_model or os.environ.get("XIAOROU_API_MODEL", "gpt-4o-mini")
    if not api_key:
        raise SystemExit("[错误] API 模式需要 OPENAI_API_KEY。\n"
                         "  export OPENAI_API_KEY=sk-...\n"
                         "  export OPENAI_BASE_URL=https://...   # 换别的兼容服务时用")
    print(f"[API] {api_base} / {model_name}")

    # 未装 SDK 时用 urllib，装了就优先用 SDK
    try:
        from openai import OpenAI
        client = OpenAI(base_url=api_base, api_key=api_key)

        def call(msgs):
            r = client.chat.completions.create(
                model=model_name, messages=msgs,
                temperature=cfg["infer"]["temperature"],
                max_tokens=args.max_new_tokens or cfg["infer"]["max_new_tokens"])
            return r.choices[0].message.content.strip()
    except ImportError:
        import urllib.error
        import urllib.request

        def call(msgs):
            body = json.dumps({
                "model": model_name, "messages": msgs,
                "temperature": cfg["infer"]["temperature"],
                "max_tokens": args.max_new_tokens or cfg["infer"]["max_new_tokens"],
            }).encode("utf-8")
            req = urllib.request.Request(
                f"{api_base}/chat/completions", data=body,
                headers={"Content-Type": "application/json",
                         "Authorization": f"Bearer {api_key}"})
            try:
                with urllib.request.urlopen(req, timeout=120) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                raise SystemExit(f"[错误] 接口返回 {e.code}：{e.read().decode('utf-8', 'ignore')[:300]}")
            return data["choices"][0]["message"]["content"].strip()

    def reply(user_text):
        system = build_system(persona, rag, kb_index, mem, user_text)
        msgs = [{"role": "system", "content": system}] + state["history"] + \
               [{"role": "user", "content": user_text}]
        answer = call(msgs)
        state["history"] += [{"role": "user", "content": user_text},
                             {"role": "assistant", "content": answer}]
        return answer

    return reply


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", choices=["local", "api"], default="local")
    ap.add_argument("--model", choices=["1.5b", "7b", "custom", "coder", "coder7b"], default="1.5b")
    ap.add_argument("--model-path", default=None)
    ap.add_argument("--adapter", default=None)
    ap.add_argument("--no-adapter", action="store_true")
    ap.add_argument("--no-4bit", action="store_true")
    ap.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    ap.add_argument("--once", default=None)
    ap.add_argument("--max-new-tokens", type=int, default=None)
    ap.add_argument("--kb", default=None)
    ap.add_argument("--no-kb", action="store_true")
    ap.add_argument("--memory", default=None, help="记忆库路径，默认 memory/memory.db")
    ap.add_argument("--no-memory", action="store_true")
    ap.add_argument("--api-base", default=None)
    ap.add_argument("--api-key", default=None)
    ap.add_argument("--api-model", default=None)
    args = ap.parse_args()

    cfg = load_config()
    persona = (ROOT / cfg["persona_file"]).read_text(encoding="utf-8").strip()

    rag, kb_index = None, None
    if not args.no_kb:
        kb_index = args.kb or str(ROOT / "data" / "kb_index.json")
        if Path(kb_index).exists():
            rag = load_rag()
            if rag:
                print(f"[检索] 已接入资料库 {kb_index}")
        else:
            kb_index = None

    mem = None if args.no_memory else load_memory(args.memory)
    if mem:
        print(f"[记忆] 已接入 {mem.path}（共 {len(mem.all())} 条）")

    state = {"history": []}
    reply = (run_api if args.backend == "api" else run_local)(
        args, cfg, persona, rag, kb_index, mem, state)

    if args.once:
        remember_auto(mem, args.once)
        print(reply(args.once))
        return

    print("小柔已就绪。/reset 清空上下文，/remember 记一条，/memory 看记忆，/exit 退出。\n")
    while True:
        try:
            user = input("你：").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见。")
            break
        if not user:
            continue
        if handle_command(user, state, mem):
            continue
        remember_auto(mem, user)
        print("小柔：", end="", flush=True)
        reply(user)
        print()


if __name__ == "__main__":
    main()
