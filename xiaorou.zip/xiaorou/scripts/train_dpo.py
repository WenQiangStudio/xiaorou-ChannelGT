#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SFT 之后的 DPO 对齐：让「该坦白时坦白、该拒绝时拒绝、该闭嘴时闭嘴」变成默认行为。

SFT 学的是「照着范例说」，DPO 学的是「两个都不错的回答里，更偏向哪一个」。
这一步对「看起来专业」提升不大，对「不像机器」提升很大，也是小模型追上来的关键一步。

用法：
    python scripts/train_dpo.py --check          # 只校验偏好数据，不需要 GPU
    python scripts/train_dpo.py                  # 在 outputs/xiaorou-lora 基础上继续训
    python scripts/train_dpo.py --beta 0.2 --epochs 2
    python scripts/train_dpo.py --data data/preference_template.jsonl

前置：先跑完 train_qlora.py，SFT adapter 存在。
"""
import argparse
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_config():
    with open(ROOT / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


def dpo_loss_from_logps(logp_w, logp_l, ref_w, ref_l, beta=0.1):
    """标准 DPO 目标：-log σ(β * ((logp_w - logp_l) - (ref_w - ref_l)))。

    纯浮点实现，不依赖 torch，可单独测试。用 softplus 写法避免 exp 溢出。
    """
    margin = (logp_w - logp_l) - (ref_w - ref_l)
    x = beta * margin
    if x >= 0:
        return math.log1p(math.exp(-x))        # -log sigmoid(x)
    return -x + math.log1p(math.exp(x))


def load_pairs(path, tokenizer_only=False):
    """读取偏好数据。返回 (pairs, errors)。"""
    pairs, errors = [], []
    for i, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as e:
            errors.append(f"第 {i} 行 JSON 错误：{e}")
            continue
        prompt = obj.get("prompt")
        if isinstance(prompt, str):
            prompt = [{"role": "user", "content": prompt}]
        if not isinstance(prompt, list) or not prompt:
            errors.append(f"第 {i} 行 prompt 必须是非空列表或字符串")
            continue
        if prompt[-1].get("role") != "user":
            errors.append(f"第 {i} 行 prompt 最后一条必须是 user")
            continue
        for k in ("chosen", "rejected"):
            if not isinstance(obj.get(k), str) or not obj[k].strip():
                errors.append(f"第 {i} 行 {k} 为空")
        if obj.get("chosen") == obj.get("rejected"):
            errors.append(f"第 {i} 行 chosen 与 rejected 完全相同")
        if errors and errors[-1].startswith(f"第 {i} 行"):
            continue
        pairs.append({"prompt": prompt,
                      "chosen": obj["chosen"].strip(),
                      "rejected": obj["rejected"].strip()})
    return pairs, errors


def check_only(path):
    pairs, errs = load_pairs(path)
    print(f"[校验] {path}")
    if errs:
        print(f"[错误] {len(errs)} 条问题：")
        for e in errs:
            print("  -", e)
        raise SystemExit(1)
    print(f"[通过] {len(pairs)} 条偏好样本，prompt/chosen/rejected 结构正确")
    shorter = sum(1 for p in pairs if len(p["chosen"]) < len(p["rejected"]) * 0.5)
    if shorter:
        print(f"[提示] {shorter} 条 chosen 明显比 rejected 短，注意别把「短」学成「好」的唯一标准")
    lens = [len(p["chosen"]) for p in pairs]
    print(f"[统计] chosen 平均 {sum(lens) // len(lens)} 字，"
          f"最短 {min(lens)}，最长 {max(lens)}")


def encode(text_ids, resp_ids, max_len):
    ids = text_ids + resp_ids
    if len(ids) > max_len:
        ids = ids[:max_len]
    return ids, len(text_ids)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="只校验数据，不训练")
    ap.add_argument("--data", default="data/preference_template.jsonl")
    ap.add_argument("--sft-adapter", default=None, help="SFT 产出的 adapter 目录")
    ap.add_argument("--output", default=None)
    ap.add_argument("--beta", type=float, default=None)
    ap.add_argument("--epochs", type=float, default=None)
    ap.add_argument("--lr", type=float, default=None)
    args = ap.parse_args()

    cfg = load_config()
    dcfg = cfg.get("dpo", {})
    data_path = ROOT / args.data

    if args.check or not data_path.exists():
        if not data_path.exists():
            raise SystemExit(f"[错误] 找不到偏好数据 {data_path}")
        check_only(data_path)
        return

    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from peft import PeftModel
    except ImportError as e:
        raise SystemExit(f"[错误] 缺少依赖：{e}\n先执行：pip install -r requirements.txt")

    if not torch.cuda.is_available():
        raise SystemExit("[错误] 没有 CUDA 显卡，DPO 需要 GPU 训练")

    pairs, errs = load_pairs(data_path)
    if errs:
        raise SystemExit("[错误] 偏好数据有问题：\n  - " + "\n  - ".join(errs))

    base = cfg["base_model"]
    sft = Path(args.sft_adapter or ROOT / cfg["train"]["output_dir"])
    if not sft.exists():
        raise SystemExit(f"[错误] 找不到 SFT adapter {sft}，先跑 train_qlora.py")
    out = Path(args.output or dcfg.get("output_dir", "outputs/xiaorou-dpo"))
    out = out if out.is_absolute() else ROOT / out
    out.mkdir(parents=True, exist_ok=True)

    beta = args.beta or dcfg.get("beta", 0.1)
    epochs = args.epochs or dcfg.get("epochs", 1)
    lr = args.lr or dcfg.get("lr", 1e-5)
    max_len = cfg.get("max_seq_length", 1536)

    tokenizer = AutoTokenizer.from_pretrained(base, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    persona = (ROOT / cfg["persona_file"]).read_text(encoding="utf-8").strip()

    print(f"[1/4] 加载 SFT 模型：{base} + {sft.name}")
    model = AutoModelForCausalLM.from_pretrained(
        base, torch_dtype=torch.bfloat16, trust_remote_code=True, device_map={"": 0})
    model = PeftModel.from_pretrained(model, str(sft), is_trainable=True)
    model.train()

    def build(item, which):
        msgs = [{"role": "system", "content": persona}] + item["prompt"]
        p_ids = tokenizer.apply_chat_template(msgs, tokenize=True, add_generation_prompt=True)
        r_ids = tokenizer(item[which], add_special_tokens=False)["input_ids"] + [tokenizer.eos_token_id]
        ids, start = encode(p_ids, r_ids, max_len)
        return ids, start

    def logprob(ids, start):
        """返回响应部分的平均 log 概率。"""
        t = torch.tensor([ids], device=model.device)
        out = model(input_ids=t, attention_mask=torch.ones_like(t)).logits
        if start >= t.shape[1]:
            return None
        logits = out[0, start - 1: t.shape[1] - 1].float()
        targets = t[0, start:]
        lp = torch.log_softmax(logits, dim=-1).gather(-1, targets.unsqueeze(-1)).squeeze(-1)
        return lp.mean()

    opt = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad], lr=lr)
    scaler = torch.cuda.amp.GradScaler(enabled=False)
    accum = dcfg.get("grad_accum", 8)

    print(f"[2/4] {len(pairs)} 条偏好样本，beta={beta}，epochs={epochs}，lr={lr}")
    step = 0
    for epoch in range(int(math.ceil(epochs))):
        total, n = 0.0, 0
        for i, item in enumerate(pairs):
            w_ids, w_start = build(item, "chosen")
            l_ids, l_start = build(item, "rejected")

            pw = logprob(w_ids, w_start)
            pl = logprob(l_ids, l_start)
            if pw is None or pl is None:
                continue
            # 参考模型：关掉 adapter 的前向
            with model.disable_adapter():
                with torch.no_grad():
                    rw = logprob(w_ids, w_start)
                    rl = logprob(l_ids, l_start)
            if rw is None or rl is None:
                continue

            margin = (pw - pl) - (rw - rl)
            loss = -torch.nn.functional.logsigmoid(beta * margin)
            (loss / accum).backward()

            total += float(loss.detach())
            n += 1
            if (i + 1) % accum == 0:
                torch.nn.utils.clip_grad_norm_(
                    [p for p in model.parameters() if p.requires_grad], 1.0)
                opt.step()
                opt.zero_grad()
                step += 1
                if step % 5 == 0:
                    print(f"  step {step} loss={total / max(1, n):.4f}")

        # 收尾时把剩下的梯度用掉
        if (len(pairs) % accum) != 0:
            opt.step()
            opt.zero_grad()
        print(f"  epoch {epoch + 1} 平均 loss={total / max(1, n):.4f}，样本 {n}")

    print(f"[3/4] 保存到 {out}")
    model.save_pretrained(str(out))
    tokenizer.save_pretrained(str(out))
    with open(out / "dpo_summary.json", "w", encoding="utf-8") as f:
        json.dump({"base_model": base, "sft_adapter": str(sft),
                   "pairs": len(pairs), "beta": beta, "epochs": epochs, "lr": lr},
                  f, ensure_ascii=False, indent=2)
    print("[4/4] 完成。推理时把 --adapter 指向这个目录即可。")
    print("      注意：DPO 训完要重新跑 evaluate.py，对齐变好但知识可能轻微退化，两边都要看。")


if __name__ == "__main__":
    main()
