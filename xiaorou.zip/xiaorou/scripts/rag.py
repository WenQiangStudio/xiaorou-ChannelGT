#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""在本地资料里检索相关片段（纯标准库 BM25，中文用二元组分词）。

单独用：
    python scripts/rag.py "二次函数顶点怎么求"
    python scripts/rag.py "怎么判断氧化还原" --topk 5

被 infer.py / api_server.py 调用时用 search()。
"""
import argparse
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_HAN = re.compile(r"[\u4e00-\u9fff]")

STOP_CHARS = set("的了是在有和就不也都很我你他她它这那什么吗呢吧啊呀为以及与或而但个上下中要会能可说对把被让从到给着过得地还又再只更最太等")
STOP_WORDS = {
    "什么", "怎么", "为什么", "如何", "哪个", "哪些", "是否", "可以", "这个", "那个",
    "我们", "你们", "他们", "因为", "所以", "但是", "如果", "就是", "这样", "那样",
    "一下", "时候", "问题", "觉得", "应该", "需要", "能够", "没有", "不是", "以及",
    "总是", "老是", "一直", "到底", "具体", "一些", "有点",
}


def keep_uni(ch):
    return ch not in STOP_CHARS


def keep_bi(a, b):
    return not (a + b in STOP_WORDS or (a in STOP_CHARS and b in STOP_CHARS))

_CACHE = {}


def tokenize(text):
    s = text.lower()
    words = ["w:" + w for w in re.findall(r"[a-z0-9_]+", s) if w not in STOP_WORDS]
    han = _HAN.findall(s)
    return words + ["u:" + c for c in han if keep_uni(c)] + \
        ["b:" + han[i] + han[i + 1] for i in range(len(han) - 1) if keep_bi(han[i], han[i + 1])]


def term_weight(token):
    """二元组和英文词是强信号，中文单字权重压到 0.45。"""
    if token.startswith("b:") or token.startswith("w:"):
        return 1.6
    return 0.45


def load(index_path):
    path = Path(index_path)
    if not path.is_absolute():
        path = ROOT / path
    key = str(path)
    if key in _CACHE:
        return _CACHE[key]
    if not path.exists():
        return None
    index = json.loads(path.read_text(encoding="utf-8"))
    _CACHE[key] = index
    return index


def search(query, index_path="data/kb_index.json", topk=3, min_score=0.0, min_best=4.0):
    """返回 [(score, source, text)]，按相关度降序。"""
    index = load(index_path)
    if not index or not index.get("docs"):
        return []
    k1 = index["params"]["k1"]
    b = index["params"]["b"]
    N = index["N"]
    avgdl = index["avgdl"] or 1.0
    df = index["df"]

    q_terms = {}
    for t in tokenize(query):
        q_terms[t] = q_terms.get(t, 0) + 1
    # 英文/数字词（如 KeyError、groupby）是强信号，命中就额外加分
    q_phrases = {p.lower() for p in re.findall(r"[a-zA-Z][a-zA-Z0-9_]{2,}", query)}

    scored = []
    for d in index["docs"]:
        score = 0.0
        for t in q_terms:
            tf = d["tf"].get(t)
            if not tf:
                continue
            n = df.get(t, 0)
            idf = math.log(1 + (N - n + 0.5) / (n + 0.5))
            denom = tf + k1 * (1 - b + b * d["len"] / avgdl)
            score += term_weight(t) * idf * tf * (k1 + 1) / denom
        if q_phrases:
            low = d["text"].lower()
            score += 3.0 * sum(1 for p in q_phrases if p in low)
        if score > min_score:
            scored.append((score, d["source"], d["text"]))

    scored.sort(key=lambda x: x[0], reverse=True)
    # 最佳分都太低，说明资料里其实没有这块内容，宁可返回空也不要硬塞无关片段
    if not scored or scored[0][0] < min_best:
        return []
    # 自适应阈值：明显低于最佳结果的片段算噪声
    cutoff = max(min_score, scored[0][0] * 0.35)
    scored = [s for s in scored if s[0] >= cutoff]
    return scored[:topk]


def build_context(query, index_path="data/kb_index.json", topk=3, max_chars=1200):
    """把检索结果拼成一段可注入 system 的资料文本。没有命中就返回空串。"""
    hits = search(query, index_path=index_path, topk=topk)
    if not hits:
        return "", []
    parts, used = [], 0
    for i, (score, source, text) in enumerate(hits, 1):
        block = f"【资料{i}｜{source}】\n{text}"
        if used + len(block) > max_chars:
            break
        parts.append(block)
        used += len(block)
    return "\n\n".join(parts), hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("query")
    ap.add_argument("--index", default="data/kb_index.json")
    ap.add_argument("--topk", type=int, default=3)
    args = ap.parse_args()

    hits = search(args.query, index_path=args.index, topk=args.topk)
    if not hits:
        print("没有命中任何片段。检查资料目录里有没有相关内容，或重新运行 build_kb.py。")
        return
    for i, (score, source, text) in enumerate(hits, 1):
        print(f"\n[{i}] {source}  score={score:.2f}")
        print(text[:300].replace("\n", " ") + ("…" if len(text) > 300 else ""))


if __name__ == "__main__":
    main()
