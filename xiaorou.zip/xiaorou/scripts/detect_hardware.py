#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""探测这台机器能跑什么，然后告诉你该用哪个配置。

不同设备不该改同一套参数：8G 笔记本、24G 台式、没有显卡的服务器，
能跑的底座、量化方式、上下文长度都不一样。这个脚本只做一件事——看清楚硬件再决定。

用法：
    python scripts/detect_hardware.py
    python scripts/detect_hardware.py --json
"""
import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def total_ram_gb():
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) / 1024 / 1024
    except OSError:
        pass
    try:
        return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1024 ** 3
    except (ValueError, OSError, AttributeError):
        return 0.0


def gpu_info():
    """先看 nvidia-smi，没有再看 torch。两条都没有就是没有。"""
    out = {"present": False, "name": "", "vram_gb": 0.0, "source": "", "vendor": ""}
    if shutil.which("nvidia-smi"):
        try:
            q = subprocess.run(
                ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=10)
            if q.returncode == 0 and q.stdout.strip():
                first = q.stdout.strip().splitlines()[0]
                name, mem = [x.strip() for x in first.split(",")[:2]]
                out.update(present=True, name=name, source="nvidia-smi",
                           vram_gb=float(mem.split()[0]) / 1024,
                           vendor="AMD" if "AMD" in name.upper() or "RADEON" in name.upper() else "NVIDIA")
                return out
        except (subprocess.SubprocessError, ValueError, IndexError):
            pass
    try:
        import torch
        if torch.cuda.is_available():
            name = torch.cuda.get_device_name(0)
            out.update(present=True, name=name, source="torch(rocm)" if getattr(torch.version, "hip", None) else "torch",
                       vram_gb=torch.cuda.get_device_properties(0).total_memory / 1024 ** 3,
                       vendor="AMD" if "AMD" in name.upper() else "NVIDIA")
    except ImportError:
        pass
    return out


def recommend(ram_gb, gpu, os_tag="linux"):
    """按显存和内存给出档位。宁可保守——小马拉大车比跑得慢更糟。

    os_tag="mac-arm" 时走统一内存，显存就等于可用内存的一部分。
    """
    if os_tag == "mac-arm":
        if ram_gb >= 32:
            return "apple-32g", "统一内存可跑 7B 4bit 甚至 bf16（MLX / llama.cpp）", "base_model_7b", 4, 2048
        if ram_gb >= 16:
            return "apple-16g", "统一内存可跑 7B 4bit（MLX / llama.cpp），训练不建议", "base_model_7b", 4, 1536
        if ram_gb >= 8:
            return "apple-8g", "只能跑 1.5B 4bit，7B 会吃满内存开始交换", "base_model", 4, 1024
        return "tiny", "本机跑不动，用 API 回退", "base_model", 0, 512
    vram = gpu["vram_gb"] if gpu["present"] else 0.0
    if vram >= 23:
        return "gpu-24g", "7B QLoRA 训练 + 7B 4bit 推理", "base_model_7b", 4, 2048
    if vram >= 15:
        return "gpu-16g", "7B 4bit 推理，1.5B 可训练", "base_model_7b", 4, 1536
    if vram >= 7:
        return "gpu-8g", "1.5B QLoRA 训练 + 1.5B 4bit 推理", "base_model", 4, 1536
    if vram > 0:
        return "gpu-small", "只能推理 1.5B，勉强；训练不行", "base_model", 8, 1024
    if ram_gb >= 16:
        return "cpu-16g", "1.5B CPU 推理（约 5-15 字/秒），训练别想", "base_model", 0, 1024
    if ram_gb >= 8:
        return "cpu-8g", "1.5B CPU 推理很慢，建议改用 API 回退", "base_model", 0, 768
    return "tiny", "本机跑不动，必须用 API 回退", "base_model", 0, 512


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--apply", action="store_true",
                    help="把推荐档位写回 config.json（原文件备份为 config.backup.json）")
    args = ap.parse_args()

    ram = total_ram_gb()
    gpu = gpu_info()
    cpu_count = os.cpu_count() or 1
    disk = shutil.disk_usage(str(ROOT)) if ROOT.exists() else None
    os_tag = "mac-arm" if (platform.system() == "Darwin" and platform.machine() == "arm64") else \
        ("windows" if platform.system() == "Windows" else "linux")
    profile, advice, model_key, bits, ctx = recommend(ram, gpu, os_tag)

    cfg = {}
    try:
        cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        pass
    base = cfg.get(model_key, "Qwen/Qwen2.5-1.5B-Instruct")

    data = {
        "cpu_cores": cpu_count,
        "ram_gb": round(ram, 1),
        "disk_free_gb": round(disk.free / 1024 ** 3, 1) if disk else None,
        "gpu": gpu,
        "profile": profile,
        "recommend_base": base,
        "load_in_4bit": bits == 4,
        "load_in_8bit": bits == 8,
        "max_seq_length": ctx,
        "can_train": bool(gpu["present"] and gpu["vram_gb"] >= 7) or profile == "apple-32g",
        "os": os_tag,
        "arch": platform.machine(),
    }

    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return

    print("=== 这台机器 ===")
    print(f"CPU：{cpu_count} 核")
    print(f"内存：{ram:.1f} GB")
    if disk:
        print(f"磁盘剩余：{disk.free / 1024 ** 3:.0f} GB")
    if gpu["present"]:
        print(f"显卡：{gpu['name']}，显存 {gpu['vram_gb']:.1f} GB")
    else:
        print("显卡：没有检测到（nvidia-smi 和 torch 都说没有）")

    print("\n=== 建议档位 ===")
    print(f"档位：{profile}")
    print(f"说明：{advice}")
    print(f"底座：{base}")
    print(f"量化：{'4bit' if bits == 4 else ('8bit' if bits == 8 else '不量化（fp32/bf16）')}")
    print(f"上下文：{ctx}")

    print("\n=== 对应命令 ===")
    if data["can_train"]:
        print(f"  ./run.sh train --model {'7b' if '7B' in base else '1.5b'}")
    else:
        print("  训练：这台机器不行，换有显卡的机器，或用云端。")
    print(f"  ./run.sh chat --model {'7b' if '7B' in base else '1.5b'}"
          + ("" if data["can_train"] else " --device cpu"))
    if not data["can_train"] and ram < 8:
        print("  或者设 OPENAI_BASE_URL / OPENAI_API_KEY 用 API 回退：")
        print("  ./run.sh chat --backend api")

    if args.apply:
        cfg_path = ROOT / "config.json"
        backup = ROOT / "config.backup.json"
        if cfg_path.exists():
            shutil.copyfile(cfg_path, backup)
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        cfg["auto"] = {
            "profile": data["profile"], "max_seq_length": data["max_seq_length"],
            "load_in_4bit": data["load_in_4bit"], "can_train": data["can_train"],
            "detected": {"cpu_cores": cpu_count, "ram_gb": data["ram_gb"],
                         "vram_gb": gpu["vram_gb"], "gpu": gpu["name"], "os": os_tag},
        }
        cfg["max_seq_length"] = data["max_seq_length"]
        cfg["train"]["batch_size"] = 2 if (gpu["present"] and gpu["vram_gb"] >= 15) else 1
        cfg["train"]["grad_accum"] = 8 if (gpu["present"] and gpu["vram_gb"] >= 15) else 16
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"\n[已写入] {cfg_path}（备份 {backup.name}）："
              f"max_seq_length={cfg['max_seq_length']}, batch={cfg['train']['batch_size']}, "
              f"grad_accum={cfg['train']['grad_accum']}")

    print("\n=== 一句话建议 ===")
    if gpu["present"] and gpu["vram_gb"] >= 23:
        print("这套硬件够训 7B，值得直接训 7B 版本，别再折腾 1.5B。")
    elif gpu["present"]:
        print("能训 1.5B，训完再上 7B 做对比，差异会很明显。")
    elif ram >= 16:
        print("没显卡只能 CPU 推理，能用但慢。要真训，租一张 24G 卡几小时就够。")
    else:
        print("这台机器跑不动，建议走 API 回退，本地只保留记忆和检索这些轻量部分。")


if __name__ == "__main__":
    main()
