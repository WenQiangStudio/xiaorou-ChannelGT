# Python 常见报错速查

## TypeError: 'NoneType' object is not subscriptable

对 None 用了 [] 或 ['键']。来源：函数漏 return；dict.get 的键不存在；re.search 没匹配上。
定位去看报错里第一个 Traceback 的位置，不是最后一行。

## KeyError

字典里没有这个键。先 print(d.keys()) 确认是拼错、大小写不一致，还是数据本身缺字段。
可能缺字段的位置用 data.get('键', 默认值)。

## Indefinite 与 AttributeError

AttributeError: 'NoneType' object has no attribute 'xxx' 同样说明前一步得到了 None。
先向上追一层，找到产出 None 的那个调用。

## IndexError: list index out of range

下标超出列表长度。循环里常见于 range(len(lst)) 写错，或以为列表非空。
用 for x in lst 代替按下标遍历，能避免大部分这类错误。

## UnboundLocalError

函数内部给某个变量赋值后，又在赋值前读取它，Python 会把它当局部变量。
需要修改全局变量时用 global，但更好的做法是把值当参数传进来。

## RecursionError: maximum recursion depth exceeded

递归没有终止条件，或规模没有缩小。检查两件事：基准情形有没有写，每次调用参数是否真的变小。

## 处理原则

不要用裸 except: 吞掉异常。捕获具体异常类型，至少记一条日志。
except Exception 可以兜底，但要知道自己在兜什么。
