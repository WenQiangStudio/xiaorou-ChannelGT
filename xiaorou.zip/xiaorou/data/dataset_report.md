# 小柔数据集报告

- 种子文件：`data/seed_sft.jsonl`
- 有效样本：**160** 条（165 轮问答，共 40233 字）
- 训练集：`data/train.jsonl`，144 条
- 验证集：`data/dev.jsonl`，16 条
- 平均单条长度：251 字

## 学科分布

| 学科 | 条数 |
| --- | --- |
| 编程 | 42 |
| 闲聊 | 38 |
| 数学 | 23 |
| 方法 | 11 |
| 物理 | 9 |
| 语文 | 9 |
| 英语 | 7 |
| 化学 | 6 |
| 历史 | 6 |
| 生物 | 5 |
| 地理 | 3 |
| 开场 | 1 |

## 检查结果

- 错误：0
- 警告：0
  - 无

## 下一步

```bash
python scripts/check_env.py          # 确认显卡和依赖
python scripts/train_qlora.py        # 开始训练 LoRA
python scripts/infer.py              # 训练完跟小柔对话
```
