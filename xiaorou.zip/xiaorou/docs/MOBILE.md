# 在手机上跑小柔

先讲清楚一个前提：**手机只做推理，不做训练**。训练、DPO 对齐、合并、量化全部在电脑上完成，把最终的 `.gguf` 传到手机即可。

## 第一步：选对量化档位

手机内存有限，档位选错会闪退或卡死。按手机内存选：

| 手机内存 | 7B 底座选 | 1.5B 底座选 |
| --- | --- | --- |
| 12G 以上旗舰 | Q4_K_M（约 4.4G） | Q4_K_M（约 1G） |
| 8G 左右主流 | Q3_K_M（约 3.5G） | Q4_K_M |
| 6G 以下 | 不建议 7B，换 1.5B | Q3_K_M（约 0.8G） |

**实话：手机上想丝滑，1.5B 的 Q4_K_M 是最稳的选择**，加载快、不发烫、不杀后台。7B 是上限，能跑但发热和耗电明显，适合偶尔用。两个底座都导出，按场景换。

导出命令（电脑上跑）：

```bash
python scripts/export_gguf.py --model-dir outputs/xiaorou-merged \
    --quants Q3_K_M Q4_K_M --out-dir outputs/gguf
```

## 第二步：把 GGUF 传到手机

- 安卓：数据线 / 网盘 / 局域网传输，放到一个找得到的目录。
- iPhone：用「文件」App 保存，再在客户端里选择导入。

## 第三步：选客户端

### 安卓

| 客户端 | 特点 | 适合 |
| --- | --- | --- |
| **KoboldCpp** | 原生支持 GGUF，有安卓构建，基于 llama.cpp | 首选，加载本地文件最直接 |
| **MLC Chat** | 官方有 Android App，针对手机做了加速 | 想要更快推理 |
| **Termux + llama.cpp** | 命令行，功能最全，能接记忆和知识库 | 想在手机上跑完整闭环 |

KoboldCpp 最简单：打开 App → 选本地 `.gguf` → 加载 → 对话。

### iPhone

- **MLC Chat**：官方 iOS App，对苹果芯片有优化，是 iOS 上最稳的选择。
- App Store 里其他基于 llama.cpp 的客户端，搜「llama」或「gguf」，选明确支持导入 GGUF 的，注意看更新时间。
- iOS 沙箱限制比安卓严，文件要通过「文件」App 分享导入，不能直接读任意目录。

## 手机端能力边界（重要）

`.gguf` 里打包了小柔的全部模型能力：语气风格、不会就直说、代码能力、回答结构。这些在任何客户端都生效。

但有三样东西是**配套 Python 程序**，普通手机客户端不自带：

- 长期记忆（`memory/memory.db`）
- 知识库检索（`knowledge/` 的 BM25）
- 代码沙箱（`code_runner.py`）

所以有两种用法：

### 用法 A：纯模型聊天（简单，推荐先用这个）

手机只加载 GGUF，记忆和知识库留在电脑。适合日常问答、写代码、闲聊。

### 用法 B：完整闭环（仅安卓，Termux）

手机上同时跑模型服务和记忆脚本，步骤：

1. Termux 里装环境：`pkg install python cmake git`，克隆并编译 llama.cpp。
2. 把 GGUF 和 `memory/` 目录复制到手机存储。
3. 启动服务：`./llama-server -m xiaorou.gguf --port 8080 --chat-template chatml`。
4. 另开一个 Termux 会话，用 `infer.py --backend api --api-base http://127.0.0.1:8080/v1`，记忆和检索就接上了。

这套能在手机上离线跑完整功能，但配置繁琐、占资源，建议玩熟用法 A 再折腾。

iPhone 受沙箱限制，做不到用法 B，只能用纯模型。

## 记忆跨设备同步

想在手机和电脑之间带走记忆：

```bash
# 电脑导出
python scripts/memory.py export mem.json
# 另一台设备导入（按内容自动去重合并）
python scripts/memory.py import mem.json
```

注意：走纯模型客户端时，记忆文件不会被自动读取，它只在 Termux 或电脑的 Python 环境里生效。
