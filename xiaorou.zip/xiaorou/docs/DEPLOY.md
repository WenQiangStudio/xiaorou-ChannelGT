# 在不同设备上跑小柔

同一套代码，硬件不同要改的是**档位**，不是代码。先跑这一条，它会告诉你该用哪档：

```bash
python scripts/detect_hardware.py            # 看这台机器适合什么
python scripts/detect_hardware.py --apply    # 把推荐值写回 config.json（自动备份）
```

`--apply` 会改写 `max_seq_length`、`batch_size`、`grad_accum`，并记录探测结果到 `config.auto`。改错了用 `config.backup.json` 还原。

## 档位对照

| 档位 | 硬件 | 能做什么 | 上下文 | 说明 |
| --- | --- | --- | --- | --- |
| `gpu-24g` | 显存 ≥ 23G | 7B QLoRA 训练 + 7B 4bit 推理 | 2048 | 一步到位，别再折腾 1.5B |
| `gpu-16g` | 显存 ≥ 15G | 7B 4bit 推理，1.5B 可训练 | 1536 | 性价比区间 |
| `gpu-8g` | 显存 ≥ 7G | 1.5B QLoRA 训练 + 1.5B 推理 | 1536 | 最常见的入门卡 |
| `gpu-small` | 显存 < 7G | 只够 1.5B 8bit 推理 | 1024 | 训练会 OOM |
| `apple-16g` | M 系列 16G 统一内存 | 7B 4bit 推理（MLX/llama.cpp） | 1536 | 训练不建议，会很烫 |
| `cpu-16g` | 16G 内存无显卡 | 1.5B CPU 推理，5-15 字/秒 | 1024 | 能用，别指望训练 |
| `tiny` | 内存 < 8G | 本机跑不动 | — | 走 API 回退 |

## 三种部署路径

### 1. 有显卡：直接跑

```bash
./run.sh train --model 1.5b        # 先训 1.5B
./run.sh chat                      # 用 adapter 对话
./run.sh serve                     # 起 OpenAI 兼容服务
```

7B 就这样换：`./run.sh train --model 7b`，8G 卡上 7B 只能推理不能训。

### 2. 没显卡：走 API 回退（推荐）

本地不装 torch，模型调用走任意 OpenAI 兼容服务，**记忆和资料检索仍然在本地**：

```bash
export OPENAI_BASE_URL=https://你的服务/v1
export OPENAI_API_KEY=sk-...
./run.sh chat --backend api
```

这条路的好处：3G 内存的老机器也能用，且人格、记忆、知识库全是本地的，只有生成这一步在外面。

### 3. 想离线、又不想装 torch：转 GGUF

先在**有显卡的机器**上合并 adapter，再转格式：

```bash
python scripts/merge_lora.py --out outputs/xiaorou-merged
# 用 llama.cpp 官方转换脚本
python convert_hf_to_gguf.py outputs/xiaorou-merged --outtype q8_0 --outfile xiaorou-f16.gguf
./llama-quantize xiaorou-f16.gguf xiaorou-q4km.gguf Q4_K_M
./llama-cli -m xiaorou-q4km.gguf -p "二次函数顶点怎么求" --chat-template chatml
```

Q4_K_M 的 1.5B 大约 1GB 内存，7B 大约 4.5GB。老笔记本、树莓派级别都能跑。

Ollama 版本（更省事）：

```bash
# Modelfile
cat > Modelfile <<'EOF'
FROM ./xiaorou-q4km.gguf
PARAMETER temperature 0.7
PARAMETER top_p 0.9
EOF
ollama create xiaorou -f Modelfile
ollama run xiaorou
```

注意：走 llama.cpp 时**记忆和检索不会自动接**，它们是小柔工程里的 Python 层。要做到「记忆 + 资料 + 离线」三件事同时成立，用 API 回退那一套，把 `OPENAI_BASE_URL` 指向本地 llama.cpp 的 server 即可：

```bash
./llama-server -m xiaorou-q4km.gguf --chat-template chatml --port 8080
export OPENAI_BASE_URL=http://127.0.0.1:8080/v1
export OPENAI_API_KEY=none
./run.sh chat --backend api
```

### 4. Mac（M 系列）

MLX 在这类机器上最快：

```bash
pip install mlx-lm
mlx_lm.generate --model Qwen/Qwen2.5-1.5B-Instruct \
  --adapter-path outputs/xiaorou-lora --prompt "二次函数顶点怎么求"
```

16G 统一内存跑 7B 4bit 没问题，32G 可以试 bf16。

## 记忆跟着人走，不跟着设备走

记忆是本地 SQLite（`memory/memory.db`），换设备时复制文件或导出 JSON：

```bash
python scripts/memory.py export mem.json     # 旧设备
python scripts/memory.py import mem.json     # 新设备，按内容去重合并
```

服务端多用户场景下，记忆按 `user` 字段分库（`memory/users/<id>.db`），不会串味：

```bash
curl "http://127.0.0.1:8000/v1/memory?user=wen"        # 看这个人记住了什么
curl -X DELETE "http://127.0.0.1:8000/v1/memory?user=wen"
```

请求时带上 `"user": "wen"` 即可。

## 显存/内存估算

| 模型 | 4bit 推理 | 4bit 训练（LoRA） | bf16 推理 |
| --- | --- | --- | --- |
| 1.5B | ~1.2G | ~3.5G（batch 2 + 1536） | ~3.5G |
| 7B | ~5G | ~9-11G（batch 1 + 1536） | ~15G |

数字随 batch 和上下文长度变化，留 20% 余量。8G 卡训 7B 会 OOM，别试。
