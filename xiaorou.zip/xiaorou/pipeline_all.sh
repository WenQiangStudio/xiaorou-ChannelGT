#!/usr/bin/env bash
# ============================================================
# 小柔 ChannelGT · 一键全流程
# 从数据到 GGUF，一条命令跑完，手机 SSH 里挂着等结果即可。
#
#   bash pipeline_all.sh                # 完整跑
#   bash pipeline_all.sh --skip-train   # 已训过，只做合并和导出
#
# 会自动：装依赖 → 建数据 → 自测 → SFT → DPO → 合并 → 取 llama.cpp → 导出 GGUF
# 任何一步失败立刻停下，不会带病往下走。
# ============================================================
set -euo pipefail
cd "$(dirname "$0")"

log() { echo; echo "========== $* =========="; }

SKIP_TRAIN=false
if [ "${1:-}" = "--skip-train" ]; then SKIP_TRAIN=true; fi

# ---------- 0. 环境确认 ----------
log "0. 环境检查"
python3 --version
if ! command -v nvidia-smi >/dev/null 2>&1; then
  echo "[错误] 没有检测到 NVIDIA 显卡。这个脚本要在 GPU 云主机上跑。"
  exit 1
fi
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader

# ---------- 1. 依赖 ----------
log "1. 安装/确认 Python 依赖"
python3 -m pip install -r requirements.txt
# llama.cpp 转换只需要 Python 标准库，量化需要编译产物，后面单独处理

# ---------- 2. 数据与自测 ----------
log "2. 构建数据并自测"
python3 scripts/build_dataset.py --strict
python3 scripts/selftest.py
python3 scripts/build_kb.py

if [ "$SKIP_TRAIN" = false ]; then
  # ---------- 3. SFT ----------
  log "3. SFT 有监督微调（QLoRA）"
  python3 scripts/train_qlora.py

  # ---------- 4. DPO ----------
  log "4. DPO 偏好对齐"
  python3 scripts/train_dpo.py
else
  log "跳过训练（--skip-train）"
fi

# ---------- 5. 合并 ----------
log "5. 合并 LoRA 权重"
python3 scripts/merge_lora.py --out outputs/xiaorou-merged

# ---------- 6. llama.cpp ----------
log "6. 准备 llama.cpp"
LLAMA_DIR="${LLAMA_CPP_DIR:-third_party/llama.cpp}"
if [ ! -f "$LLAMA_DIR/convert_hf_to_gguf.py" ]; then
  echo "未发现 llama.cpp，开始克隆并编译（约 10-20 分钟，只做一次）"
  mkdir -p third_party
  git clone --depth 1 https://github.com/ggml-org/llama.cpp "$LLAMA_DIR"
fi
if [ ! -x "$LLAMA_DIR/build/bin/llama-quantize" ]; then
  echo "编译 llama.cpp"
  cmake -S "$LLAMA_DIR" -B "$LLAMA_DIR/build" -DLLAMA_CURL=OFF
  cmake --build "$LLAMA_DIR/build" --config Release -j"$(nproc)"
fi

# ---------- 7. 导出 GGUF ----------
log "7. 导出并量化 GGUF"
python3 scripts/export_gguf.py \
  --model-dir outputs/xiaorou-merged \
  --llama-cpp "$LLAMA_DIR" \
  --quants Q3_K_M Q4_K_M Q5_K_M \
  --out-dir outputs/gguf

# ---------- 完成 ----------
log "全部完成"
echo "GGUF 产物："
ls -lh outputs/gguf/*.gguf
echo
echo "下一步：把 outputs/gguf 里的 .gguf 下载到手机，用 MLC LLM / KoboldCpp 导入。"
echo "低配手机选 q3_k_m，主流手机选 q4_k_m。"
