#!/usr/bin/env bash
# 小柔 一键脚本
#   ./run.sh auto      探测硬件并把推荐档位写回 config.json
#   ./run.sh prepare   校验数据、跑自测、建资料索引（不需要显卡）
#   ./run.sh train     训练 LoRA（需要 GPU）
#   ./run.sh chat      命令行对话
#   ./run.sh eval      跑评测（需要 GPU）
#   ./run.sh serve     启动 API
#   ./run.sh gguf      合并模型并导出 GGUF（需 llama.cpp）
#   ./run.sh hw        看这台机器能跑什么
#   ./run.sh mem list  看记住了什么（add/search/forget 同理）
set -euo pipefail
cd "$(dirname "$0")"

case "${1:-prepare}" in
  auto)
    python3 scripts/detect_hardware.py --apply
    ;;
  prepare)
    python3 scripts/build_dataset.py --strict
    python3 scripts/selftest.py
    python3 scripts/build_kb.py
    ;;
  train)
    shift || true
    python3 scripts/train_qlora.py "$@"
    ;;
  chat)
    shift || true
    python3 scripts/infer.py "$@"
    ;;
  eval)
    shift || true
    python3 scripts/evaluate.py "$@"
    ;;
  serve)
    shift || true
    python3 scripts/api_server.py "$@"
    ;;
  gguf)
    shift || true
    python3 scripts/export_gguf.py "$@"
    ;;
  mem)
    shift || true
    python3 scripts/memory.py "$@"
    ;;
  hw)
    python3 scripts/detect_hardware.py
    ;;
  *)
    echo "用法: ./run.sh [auto|prepare|hw|train|chat|eval|serve|mem|gguf]"
    exit 1
    ;;
esac
